package com.devsenai2a.petshop.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.devsenai2a.petshop.entities.Produto;
import com.devsenai2a.petshop.repositories.ProdutoRepository;

@Service
public class ProdutoService {

    @Autowired
    private ProdutoRepository produtoRepository;

    @Autowired
    private CategoriaService categoriaService;

    // Retorna todos os produtos ativos de uma categoria
    public List<Produto> getProdutosPorCategoria(Long idCategoria) {
        return produtoRepository.findByCategoriaIdAndAtivoTrue(idCategoria);
    }

    public List<Produto> listarTodos() {
        return produtoRepository.findAll();
    }

    public Produto buscarPorId(Long id) {
        return produtoRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Produto não encontrado com id: " + id));
    }

    public Produto criar(Produto produto) {

        if (produto.getCategoria() != null && produto.getCategoria().getId() != null) {
            produto.setCategoria(
                categoriaService.buscarPorId(produto.getCategoria().getId())
            );
        }

        if (produto.getAtivo() == null) {
            produto.setAtivo(true);
        }

        if (produto.getQtdEstoque() == null) {
            produto.setQtdEstoque(0);
        }

        return produtoRepository.save(produto);
    }

    public Produto atualizar(Long id, Produto produtoAtualizado) {

        Produto existing = buscarPorId(id);

        existing.setNome(produtoAtualizado.getNome());
        existing.setDescricao(produtoAtualizado.getDescricao());
        existing.setPreco(produtoAtualizado.getPreco());
        existing.setPrecoDesconto(produtoAtualizado.getPrecoDesconto());
        existing.setImagem(produtoAtualizado.getImagem());
        existing.setQtdEstoque(produtoAtualizado.getQtdEstoque());
        existing.setAtivo(produtoAtualizado.getAtivo());

        if (produtoAtualizado.getCategoria() != null &&
            produtoAtualizado.getCategoria().getId() != null) {

            existing.setCategoria(
                categoriaService.buscarPorId(produtoAtualizado.getCategoria().getId())
            );
        }

        return produtoRepository.save(existing);
    }

    public void deletar(Long id) {
        Produto produto = buscarPorId(id);
        produtoRepository.delete(produto);
        System.out.println("Produto " + id + " deletado com sucesso!");
    }
}