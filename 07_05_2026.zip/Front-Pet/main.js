// ==================== MAIN PAGE FUNCTIONS ====================
let allProdutosCache = [];
let currentUser = null;
let usersDB = [];
let ordersDB = [];

// Inicializar dados
function initData() {
    // Usuários
    if (!localStorage.getItem('petcare_users')) {
        usersDB = [
            { id: 1, nome: "Administrador", email: "admin@petcare.com", senha: "admin123", role: "ADMIN", createdAt: new Date().toISOString() },
            { id: 2, nome: "João Silva", email: "joao@email.com", senha: "123456", role: "USER", createdAt: new Date().toISOString() }
        ];
        localStorage.setItem('petcare_users', JSON.stringify(usersDB));
    } else {
        usersDB = JSON.parse(localStorage.getItem('petcare_users'));
    }
    
    // Pedidos
    if (!localStorage.getItem('petcare_orders')) {
        ordersDB = [];
        localStorage.setItem('petcare_orders', JSON.stringify(ordersDB));
    } else {
        ordersDB = JSON.parse(localStorage.getItem('petcare_orders'));
    }
    
    // Produtos
    if (!localStorage.getItem('petcare_produtos')) {
        allProdutosCache = [
            { id: 1, nome: "Ração Premium para Cães", descricao: "Ração super premium para cães adultos, com ingredientes naturais e alto teor de proteína.", preco: 89.90, precoDesconto: 79.90, qtdEstoque: 50, imagem: "https://images.unsplash.com/photo-1569925382188-5e10d9b81c1d?w=300", ativo: true, categoria: { id: 1, nome: "Rações" } },
            { id: 2, nome: "Brinquedo Pelúcia", descricao: "Brinquedo macio e resistente para cães de todos os portes.", preco: 35.90, precoDesconto: null, qtdEstoque: 30, imagem: "https://images.unsplash.com/photo-1576201836106-db1758fd1c97?w=300", ativo: true, categoria: { id: 2, nome: "Brinquedos" } },
            { id: 3, nome: "Cama Confortável", descricao: "Cama macia e confortável para seu pet descansar.", preco: 129.90, precoDesconto: 99.90, qtdEstoque: 15, imagem: "https://images.unsplash.com/photo-1545249390-6bdfa286032f?w=300", ativo: true, categoria: { id: 3, nome: "Camas" } },
            { id: 4, nome: "Coleira Antipulgas", descricao: "Coleira eficaz contra pulgas e carrapatos.", preco: 45.90, precoDesconto: 39.90, qtdEstoque: 40, imagem: "https://images.unsplash.com/photo-1582562124811-c09040d0a901?w=300", ativo: true, categoria: { id: 4, nome: "Acessórios" } }
        ];
        localStorage.setItem('petcare_produtos', JSON.stringify(allProdutosCache));
    } else {
        allProdutosCache = JSON.parse(localStorage.getItem('petcare_produtos'));
    }
    
    // Carregar sessão do usuário
    const savedSession = localStorage.getItem('petcare_session');
    if (savedSession) {
        try {
            const session = JSON.parse(savedSession);
            const user = usersDB.find(u => u.id === session.userId);
            if (user) {
                currentUser = { ...user, senha: undefined };
                updateUIForLoggedInUser();
            }
        } catch(e) {}
    }
}

// ==================== AUTENTICAÇÃO ====================
function login(email, senha) {
    const user = usersDB.find(u => u.email === email && u.senha === senha);
    
    if (user) {
        currentUser = { ...user, senha: undefined };
        localStorage.setItem('petcare_session', JSON.stringify({ userId: user.id, role: user.role }));
        updateUIForLoggedInUser();
        showToast(`Bem-vindo, ${user.nome}!`, 'success');
        closeLoginModal();
        return true;
    } else {
        showToast('Email ou senha incorretos!', 'error');
        return false;
    }
}

function logout() {
    currentUser = null;
    localStorage.removeItem('petcare_session');
    updateUIForLoggedOutUser();
    showToast('Você saiu da sua conta', 'info');
    backToProducts();
}

function register(nome, email, senha, confirmSenha) {
    if (senha !== confirmSenha) {
        showToast('As senhas não coincidem!', 'error');
        return false;
    }
    
    if (senha.length < 6) {
        showToast('A senha deve ter pelo menos 6 caracteres!', 'error');
        return false;
    }
    
    if (usersDB.find(u => u.email === email)) {
        showToast('Email já cadastrado!', 'error');
        return false;
    }
    
    const newUser = {
        id: usersDB.length + 1,
        nome: nome,
        email: email,
        senha: senha,
        role: 'USER',
        createdAt: new Date().toISOString()
    };
    
    usersDB.push(newUser);
    localStorage.setItem('petcare_users', JSON.stringify(usersDB));
    showToast('Cadastro realizado com sucesso! Faça login.', 'success');
    closeRegisterModal();
    openLoginModal();
    return true;
}

function updateProfile(nome, email, senha = null) {
    if (!currentUser) return false;
    
    const userIndex = usersDB.findIndex(u => u.id === currentUser.id);
    if (userIndex === -1) return false;
    
    const emailExists = usersDB.find(u => u.email === email && u.id !== currentUser.id);
    if (emailExists) {
        showToast('Email já está em uso!', 'error');
        return false;
    }
    
    usersDB[userIndex].nome = nome;
    usersDB[userIndex].email = email;
    if (senha && senha.trim()) {
        usersDB[userIndex].senha = senha;
    }
    
    localStorage.setItem('petcare_users', JSON.stringify(usersDB));
    currentUser = { ...usersDB[userIndex], senha: undefined };
    localStorage.setItem('petcare_session', JSON.stringify({ userId: currentUser.id, role: currentUser.role }));
    
    updateUIForLoggedInUser();
    showToast('Perfil atualizado!', 'success');
    backToProducts();
    return true;
}

function getUserOrders() {
    if (!currentUser) return [];
    return ordersDB.filter(o => o.userId === currentUser.id).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

function isLoggedIn() {
    return currentUser !== null;
}

function getCurrentUser() {
    return currentUser;
}

function isAdmin() {
    return currentUser && currentUser.role === 'ADMIN';
}

// ==================== UI UPDATES ====================
function updateUIForLoggedInUser() {
    const userNameDisplay = document.getElementById('userNameDisplay');
    const dropdownUserName = document.getElementById('dropdownUserName');
    const dropdownUserRole = document.getElementById('dropdownUserRole');
    
    if (userNameDisplay) userNameDisplay.textContent = currentUser.nome.split(' ')[0];
    if (dropdownUserName) dropdownUserName.textContent = currentUser.nome;
    if (dropdownUserRole) dropdownUserRole.textContent = currentUser.role === 'ADMIN' ? 'Administrador' : 'Cliente';
    
    const loggedOutMenu = document.getElementById('loggedOutMenu');
    const loggedInMenu = document.getElementById('loggedInMenu');
    
    if (loggedOutMenu) loggedOutMenu.classList.add('hidden');
    if (loggedInMenu) loggedInMenu.classList.remove('hidden');
    
    updateCartBadge();
}

function updateUIForLoggedOutUser() {
    const userNameDisplay = document.getElementById('userNameDisplay');
    if (userNameDisplay) userNameDisplay.textContent = 'Entrar';
    
    const loggedOutMenu = document.getElementById('loggedOutMenu');
    const loggedInMenu = document.getElementById('loggedInMenu');
    
    if (loggedOutMenu) loggedOutMenu.classList.remove('hidden');
    if (loggedInMenu) loggedInMenu.classList.add('hidden');
}

function updateCartBadge() {
    const cart = JSON.parse(localStorage.getItem('petcare_cart') || '[]');
    const total = cart.reduce((sum, item) => sum + item.quantidade, 0);
    const badge = document.getElementById('cartBadge');
    if (badge) badge.textContent = total;
}

// ==================== PRODUTOS ====================
function loadProdutos() {
    const grid = document.getElementById('produtosGrid');
    const produtos = allProdutosCache.filter(p => p.ativo !== false);
    
    if (produtos.length === 0) {
        grid.innerHTML = '<div class="col-span-full text-center py-12">Nenhum produto cadastrado</div>';
        return;
    }
    
    grid.innerHTML = produtos.map(p => {
        const desconto = p.precoDesconto && p.precoDesconto < p.preco;
        const percentual = desconto ? Math.round(((p.preco - p.precoDesconto) / p.preco) * 100) : 0;
        return `
        <div class="product-card bg-white rounded-xl shadow-sm hover:shadow-xl overflow-hidden group" onclick="showProductDetail(${p.id})">
            <div class="relative">
                ${desconto ? `<div class="absolute top-2 left-2 bg-red-500 text-white px-2 py-1 rounded-md text-xs font-bold z-10">${percentual}% OFF</div>` : ''}
                <div class="bg-gray-100 p-6 flex items-center justify-center h-48">
                    ${p.imagem ? `<img src="${p.imagem}" class="h-32 object-contain group-hover:scale-110 transition" onerror="this.src=''">` : `<i class="fas fa-box text-6xl text-gray-400"></i>`}
                </div>
            </div>
            <div class="p-4">
                <h3 class="font-semibold text-gray-800 mb-2">${p.nome}</h3>
                <p class="text-xs text-gray-500 mb-2">${p.categoria?.nome || 'Sem categoria'}</p>
                <div class="flex items-baseline gap-2 mb-3">
                    <span class="text-2xl font-bold text-orange-500">R$ ${(p.precoDesconto || p.preco).toFixed(2)}</span>
                    ${p.precoDesconto ? `<span class="text-sm text-gray-400 line-through">R$ ${p.preco.toFixed(2)}</span>` : ''}
                </div>
                <button onclick="event.stopPropagation(); addToCart(${p.id})" class="w-full bg-orange-500 text-white py-2 rounded-lg font-semibold hover:bg-orange-600 transition flex items-center justify-center gap-2">
                    <i class="fas fa-shopping-cart"></i> Comprar
                </button>
            </div>
        </div>`;
    }).join('');
}

function showProductDetail(productId) {
    const produto = allProdutosCache.find(p => p.id === productId);
    if (!produto) return;
    
    const desconto = produto.precoDesconto && produto.precoDesconto < produto.preco;
    const percentual = desconto ? Math.round(((produto.preco - produto.precoDesconto) / produto.preco) * 100) : 0;
    
    const detailHtml = `
        <div class="grid md:grid-cols-2 gap-8 p-6 md:p-8">
            <div class="bg-gray-100 rounded-2xl flex items-center justify-center p-8">
                ${produto.imagem ? 
                    `<img src="${produto.imagem}" class="max-h-96 w-full object-contain rounded-xl" onerror="this.src=''">` : 
                    `<i class="fas fa-box-open text-8xl text-gray-400"></i>`
                }
            </div>
            <div class="space-y-5">
                <div>
                    <h1 class="text-3xl md:text-4xl font-bold text-gray-800">${produto.nome}</h1>
                    ${produto.categoria ? `<p class="text-orange-500 mt-1"><i class="fas fa-tag mr-1"></i>${produto.categoria.nome}</p>` : ''}
                </div>
                <div class="border-t border-b py-4">
                    <div class="flex items-baseline gap-3">
                        <span class="text-3xl font-bold text-orange-500">R$ ${(produto.precoDesconto || produto.preco).toFixed(2)}</span>
                        ${produto.precoDesconto ? `<span class="text-lg text-gray-400 line-through">R$ ${produto.preco.toFixed(2)}</span>` : ''}
                        ${desconto ? `<span class="bg-red-100 text-red-600 px-2 py-1 rounded-md text-sm font-bold">-${percentual}%</span>` : ''}
                    </div>
                </div>
                <div>
                    <h3 class="font-semibold text-gray-700 mb-2">📝 Descrição</h3>
                    <p class="text-gray-600">${produto.descricao || 'Sem descrição detalhada.'}</p>
                </div>
                <button onclick="addToCart(${produto.id})" class="w-full bg-gradient-to-r from-orange-500 to-amber-600 text-white font-bold py-3 rounded-xl transition flex items-center justify-center gap-2">
                    <i class="fas fa-shopping-cart"></i> Adicionar ao Carrinho
                </button>
                <button onclick="backToProducts()" class="w-full border-2 border-orange-300 text-orange-600 py-3 rounded-xl hover:bg-orange-50 transition font-semibold">
                    ← Continuar comprando
                </button>
            </div>
        </div>
    `;
    
    document.getElementById('produtoDetailContent').innerHTML = detailHtml;
    document.getElementById('produtosSection').classList.add('hidden');
    document.getElementById('produtoDetailSection').classList.remove('hidden');
    document.getElementById('myOrdersSection').classList.add('hidden');
    document.getElementById('editProfileSection').classList.add('hidden');
}

function addToCart(productId, quantity = 1) {
    const produto = allProdutosCache.find(p => p.id === productId);
    
    if (!produto) {
        showToast('Produto não encontrado!', 'error');
        return;
    }
    
    let cart = JSON.parse(localStorage.getItem('petcare_cart') || '[]');
    const existingIndex = cart.findIndex(item => item.id === productId);
    
    if (existingIndex !== -1) {
        cart[existingIndex].quantidade += quantity;
    } else {
        cart.push({
            id: produto.id,
            nome: produto.nome,
            preco: produto.precoDesconto || produto.preco,
            precoOriginal: produto.preco,
            imagem: produto.imagem,
            quantidade: quantity,
            estoque: produto.qtdEstoque || 0
        });
    }
    
    localStorage.setItem('petcare_cart', JSON.stringify(cart));
    updateCartBadge();
    showToast(`${produto.nome} adicionado ao carrinho!`, 'success');
}

// ==================== NAVEGAÇÃO ====================
function backToProducts() {
    document.getElementById('produtosSection').classList.remove('hidden');
    document.getElementById('produtoDetailSection').classList.add('hidden');
    document.getElementById('myOrdersSection').classList.add('hidden');
    document.getElementById('editProfileSection').classList.add('hidden');
    loadProdutos();
}

function scrollToProducts() {
    document.getElementById('produtosSection').scrollIntoView({ behavior: 'smooth' });
}

function viewMyOrders() {
    if (!isLoggedIn()) {
        openLoginModal();
        return;
    }
    
    const orders = getUserOrders();
    const ordersList = document.getElementById('myOrdersList');
    
    if (orders.length === 0) {
        ordersList.innerHTML = '<div class="text-center py-8 text-gray-500"><i class="fas fa-box-open text-4xl mb-2"></i><p>Você ainda não fez nenhum pedido</p></div>';
    } else {
        ordersList.innerHTML = orders.map(order => `
            <div class="border rounded-xl p-4 bg-gray-50">
                <div class="flex justify-between items-start mb-3">
                    <div>
                        <span class="font-bold text-gray-700">Pedido #${order.id}</span>
                        <p class="text-sm text-gray-500">${new Date(order.createdAt).toLocaleDateString('pt-BR')}</p>
                    </div>
                    <span class="px-3 py-1 rounded-full text-sm font-semibold bg-yellow-100 text-yellow-700">${order.status}</span>
                </div>
                <div class="space-y-2">
                    ${order.items.map(item => `
                        <div class="flex justify-between text-sm">
                            <span>${item.nome} x${item.quantidade}</span>
                            <span class="font-medium">R$ ${(item.preco * item.quantidade).toFixed(2)}</span>
                        </div>
                    `).join('')}
                </div>
                <div class="border-t mt-3 pt-3 flex justify-between font-bold">
                    <span>Total</span>
                    <span class="text-orange-500">R$ ${order.total.toFixed(2)}</span>
                </div>
            </div>
        `).join('');
    }
    
    document.getElementById('produtosSection').classList.add('hidden');
    document.getElementById('produtoDetailSection').classList.add('hidden');
    document.getElementById('myOrdersSection').classList.remove('hidden');
    document.getElementById('editProfileSection').classList.add('hidden');
}

function editMyProfile() {
    if (!isLoggedIn()) {
        openLoginModal();
        return;
    }
    
    document.getElementById('editNome').value = currentUser.nome;
    document.getElementById('editEmail').value = currentUser.email;
    document.getElementById('editSenha').value = '';
    
    document.getElementById('produtosSection').classList.add('hidden');
    document.getElementById('produtoDetailSection').classList.add('hidden');
    document.getElementById('myOrdersSection').classList.add('hidden');
    document.getElementById('editProfileSection').classList.remove('hidden');
}

// ==================== MODAIS ====================
function openLoginModal() {
    const modal = document.getElementById('loginModal');
    if (modal) {
        modal.classList.remove('hidden');
        modal.classList.add('flex');
    }
}

function closeLoginModal() {
    const modal = document.getElementById('loginModal');
    if (modal) {
        modal.classList.add('hidden');
        modal.classList.remove('flex');
    }
}

function openRegisterModal() {
    const modal = document.getElementById('registerModal');
    if (modal) {
        modal.classList.remove('hidden');
        modal.classList.add('flex');
    }
}

function closeRegisterModal() {
    const modal = document.getElementById('registerModal');
    if (modal) {
        modal.classList.add('hidden');
        modal.classList.remove('flex');
    }
}

// ==================== TOAST ====================
function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `fixed bottom-4 right-4 z-50 px-5 py-3 rounded-xl shadow-lg flex items-center gap-2 animate-slide-in ${
        type === 'success' ? 'bg-green-500 text-white' : 
        type === 'error' ? 'bg-red-500 text-white' : 
        'bg-blue-500 text-white'
    }`;
    const icon = type === 'success' ? 'fa-check-circle' : (type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle');
    toast.innerHTML = `<i class="fas ${icon}"></i><span>${message}</span>`;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// ==================== EVENTOS ====================
document.addEventListener('DOMContentLoaded', () => {
    initData();
    loadProdutos();
    updateCartBadge();
    
    // Login form
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const email = document.getElementById('loginEmail').value;
            const senha = document.getElementById('loginPassword').value;
            login(email, senha);
        });
    }
    
    // Register form
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const nome = document.getElementById('regNome').value;
            const email = document.getElementById('regEmail').value;
            const senha = document.getElementById('regPassword').value;
            const confirm = document.getElementById('regConfirmPassword').value;
            register(nome, email, senha, confirm);
        });
    }
    
    // Edit profile form
    const editProfileForm = document.getElementById('editProfileForm');
    if (editProfileForm) {
        editProfileForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const nome = document.getElementById('editNome').value;
            const email = document.getElementById('editEmail').value;
            const senha = document.getElementById('editSenha').value;
            updateProfile(nome, email, senha);
        });
    }
    
    // Search
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            const term = e.target.value.toLowerCase();
            const filtered = allProdutosCache.filter(p => p.nome.toLowerCase().includes(term) && p.ativo !== false);
            const grid = document.getElementById('produtosGrid');
            if (filtered.length === 0) {
                grid.innerHTML = '<div class="col-span-full text-center py-12">Nenhum produto encontrado</div>';
            } else {
                grid.innerHTML = filtered.map(p => {
                    const desconto = p.precoDesconto && p.precoDesconto < p.preco;
                    const percentual = desconto ? Math.round(((p.preco - p.precoDesconto) / p.preco) * 100) : 0;
                    return `
                    <div class="product-card bg-white rounded-xl shadow-sm hover:shadow-xl overflow-hidden group" onclick="showProductDetail(${p.id})">
                        <div class="relative">
                            ${desconto ? `<div class="absolute top-2 left-2 bg-red-500 text-white px-2 py-1 rounded-md text-xs font-bold z-10">${percentual}% OFF</div>` : ''}
                            <div class="bg-gray-100 p-6 flex items-center justify-center h-48">
                                ${p.imagem ? `<img src="${p.imagem}" class="h-32 object-contain group-hover:scale-110 transition" onerror="this.src=''">` : `<i class="fas fa-box text-6xl text-gray-400"></i>`}
                            </div>
                        </div>
                        <div class="p-4">
                            <h3 class="font-semibold text-gray-800 mb-2">${p.nome}</h3>
                            <p class="text-xs text-gray-500 mb-2">${p.categoria?.nome || 'Sem categoria'}</p>
                            <div class="flex items-baseline gap-2 mb-3">
                                <span class="text-2xl font-bold text-orange-500">R$ ${(p.precoDesconto || p.preco).toFixed(2)}</span>
                                ${p.precoDesconto ? `<span class="text-sm text-gray-400 line-through">R$ ${p.preco.toFixed(2)}</span>` : ''}
                            </div>
                            <button onclick="event.stopPropagation(); addToCart(${p.id})" class="w-full bg-orange-500 text-white py-2 rounded-lg font-semibold hover:bg-orange-600 transition flex items-center justify-center gap-2">
                                <i class="fas fa-shopping-cart"></i> Comprar
                            </button>
                        </div>
                    </div>`;
                }).join('');
            }
        });
    }
    
    // User dropdown
    const userMenuBtn = document.getElementById('userMenuBtn');
    const userDropdown = document.getElementById('userDropdown');
    
    if (userMenuBtn) {
        userMenuBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            if (userDropdown) userDropdown.classList.toggle('hidden');
        });
    }
    
    document.addEventListener('click', () => {
        if (userDropdown) userDropdown.classList.add('hidden');
    });
    
    if (userDropdown) {
        userDropdown.addEventListener('click', (e) => e.stopPropagation());
    }
});

// Fechar modais clicando fora
window.onclick = (e) => {
    const loginModal = document.getElementById('loginModal');
    const registerModal = document.getElementById('registerModal');
    if (e.target === loginModal) closeLoginModal();
    if (e.target === registerModal) closeRegisterModal();
};