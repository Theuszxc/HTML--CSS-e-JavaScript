// ==================== MÓDULO DE AUTENTICAÇÃO ====================
let currentUser = null;
let usersDB = [];
let ordersDB = [];
let produtosDB = [];
let categoriasDB = [];

// Inicializar dados
function initAuth() {
    // Carregar usuários
    if (!localStorage.getItem('petcare_users')) {
        usersDB = [
            { id: 1, nome: "Administrador", email: "admin@petcare.com", senha: "admin123", role: "ADMIN", createdAt: new Date().toISOString() },
            { id: 2, nome: "João Silva", email: "joao@email.com", senha: "123456", role: "USER", createdAt: new Date().toISOString() }
        ];
        localStorage.setItem('petcare_users', JSON.stringify(usersDB));
    } else {
        usersDB = JSON.parse(localStorage.getItem('petcare_users'));
    }
    
    // Carregar pedidos
    if (!localStorage.getItem('petcare_orders')) {
        ordersDB = [];
        localStorage.setItem('petcare_orders', JSON.stringify(ordersDB));
    } else {
        ordersDB = JSON.parse(localStorage.getItem('petcare_orders'));
    }
    
    // Carregar produtos demo se não existirem
    if (!localStorage.getItem('petcare_produtos')) {
        produtosDB = [
            { id: 1, nome: "Ração Premium para Cães", descricao: "Ração super premium para cães adultos", preco: 89.90, precoDesconto: 79.90, qtdEstoque: 50, imagem: "https://images.unsplash.com/photo-1569925382188-5e10d9b81c1d?w=300", ativo: true, categoria: { id: 1, nome: "Rações" } },
            { id: 2, nome: "Brinquedo Pelúcia", descricao: "Brinquedo macio para cães", preco: 35.90, precoDesconto: null, qtdEstoque: 30, imagem: "https://images.unsplash.com/photo-1576201836106-db1758fd1c97?w=300", ativo: true, categoria: { id: 2, nome: "Brinquedos" } },
            { id: 3, nome: "Cama Confortável", descricao: "Cama macia e confortável", preco: 129.90, precoDesconto: 99.90, qtdEstoque: 15, imagem: "https://images.unsplash.com/photo-1545249390-6bdfa286032f?w=300", ativo: true, categoria: { id: 3, nome: "Camas" } }
        ];
        localStorage.setItem('petcare_produtos', JSON.stringify(produtosDB));
    } else {
        produtosDB = JSON.parse(localStorage.getItem('petcare_produtos'));
    }
    
    // Carregar categorias demo
    if (!localStorage.getItem('petcare_categorias')) {
        categoriasDB = [
            { id: 1, nome: "Rações", icon: "fa-dog", descricao: "Alimentação de qualidade", ativo: true },
            { id: 2, nome: "Brinquedos", icon: "fa-football", descricao: "Diversão garantida", ativo: true },
            { id: 3, nome: "Camas", icon: "fa-bed", descricao: "Conforto para seu pet", ativo: true }
        ];
        localStorage.setItem('petcare_categorias', JSON.stringify(categoriasDB));
    } else {
        categoriasDB = JSON.parse(localStorage.getItem('petcare_categorias'));
    }
    
    // Verificar sessão
    const savedSession = localStorage.getItem('petcare_session');
    if (savedSession) {
        try {
            const session = JSON.parse(savedSession);
            const user = usersDB.find(u => u.id === session.userId);
            if (user) {
                currentUser = { ...user, senha: undefined };
                updateUIForLoggedInUser();
            } else {
                localStorage.removeItem('petcare_session');
            }
        } catch(e) {}
    }
}

// Login
function login(email, senha) {
    const user = usersDB.find(u => u.email === email && u.senha === senha);
    
    if (user) {
        currentUser = { ...user, senha: undefined };
        localStorage.setItem('petcare_session', JSON.stringify({ userId: user.id, role: user.role }));
        updateUIForLoggedInUser();
        showToast(`Bem-vindo, ${user.nome}!`, 'success');
        closeLoginModal();
        return true;
    } else {
        showStatusMessage('Email ou senha incorretos!', 'error');
        return false;
    }
}

// Logout
function logout() {
    currentUser = null;
    localStorage.removeItem('petcare_session');
    updateUIForLoggedOutUser();
    showToast('Você saiu da sua conta', 'info');
    if (window.location.pathname.includes('admin.html')) {
        window.location.href = 'index.html';
    }
}

// Registrar
function register(nome, email, senha, confirmSenha) {
    if (senha !== confirmSenha) {
        showStatusMessage('As senhas não coincidem!', 'error');
        return false;
    }
    
    if (senha.length < 6) {
        showStatusMessage('A senha deve ter pelo menos 6 caracteres!', 'error');
        return false;
    }
    
    if (usersDB.find(u => u.email === email)) {
        showStatusMessage('Email já cadastrado!', 'error');
        return false;
    }
    
    const newUser = {
        id: usersDB.length + 1,
        nome: nome,
        email: email,
        senha: senha,
        role: 'USER',
        createdAt: new Date().toISOString()
    };
    
    usersDB.push(newUser);
    localStorage.setItem('petcare_users', JSON.stringify(usersDB));
    showStatusMessage('Cadastro realizado com sucesso! Faça login.', 'success');
    closeRegisterModal();
    openLoginModal();
    return true;
}

// Atualizar perfil
function updateProfile(nome, email, senha = null) {
    if (!currentUser) return false;
    
    const userIndex = usersDB.findIndex(u => u.id === currentUser.id);
    if (userIndex === -1) return false;
    
    const emailExists = usersDB.find(u => u.email === email && u.id !== currentUser.id);
    if (emailExists) {
        showStatusMessage('Email já está em uso!', 'error');
        return false;
    }
    
    usersDB[userIndex].nome = nome;
    usersDB[userIndex].email = email;
    if (senha && senha.trim()) {
        usersDB[userIndex].senha = senha;
    }
    
    localStorage.setItem('petcare_users', JSON.stringify(usersDB));
    currentUser = { ...usersDB[userIndex], senha: undefined };
    localStorage.setItem('petcare_session', JSON.stringify({ userId: currentUser.id, role: currentUser.role }));
    
    updateUIForLoggedInUser();
    showToast('Perfil atualizado!', 'success');
    return true;
}

// Adicionar pedido
function addOrder(cartItems, total) {
    if (!currentUser) return false;
    
    const order = {
        id: ordersDB.length + 1,
        userId: currentUser.id,
        userName: currentUser.nome,
        items: cartItems.map(item => ({ ...item })),
        total: total,
        status: 'Pendente',
        createdAt: new Date().toISOString()
    };
    
    ordersDB.push(order);
    localStorage.setItem('petcare_orders', JSON.stringify(ordersDB));
    return true;
}

// Obter pedidos do usuário
function getUserOrders() {
    if (!currentUser) return [];
    return ordersDB.filter(o => o.userId === currentUser.id).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

// Verificar se é admin
function isAdmin() {
    return currentUser && currentUser.role === 'ADMIN';
}

function isLoggedIn() {
    return currentUser !== null;
}

function getCurrentUser() {
    return currentUser;
}

// UI Updates
function updateUIForLoggedInUser() {
    const userNameDisplay = document.getElementById('userNameDisplay');
    const dropdownUserName = document.getElementById('dropdownUserName');
    const dropdownUserRole = document.getElementById('dropdownUserRole');
    const adminLink = document.getElementById('adminLink');
    
    if (userNameDisplay) userNameDisplay.textContent = currentUser.nome.split(' ')[0];
    if (dropdownUserName) dropdownUserName.textContent = currentUser.nome;
    if (dropdownUserRole) dropdownUserRole.textContent = currentUser.role === 'ADMIN' ? 'Administrador' : 'Cliente';
    
    const loggedOutMenu = document.getElementById('loggedOutMenu');
    const loggedInMenu = document.getElementById('loggedInMenu');
    
    if (loggedOutMenu) loggedOutMenu.classList.add('hidden');
    if (loggedInMenu) loggedInMenu.classList.remove('hidden');
    
    if (adminLink && isAdmin()) {
        adminLink.classList.remove('hidden');
    } else if (adminLink) {
        adminLink.classList.add('hidden');
    }
    
    // Atualizar carrinho badge
    updateCartBadge();
}

function updateUIForLoggedOutUser() {
    const userNameDisplay = document.getElementById('userNameDisplay');
    if (userNameDisplay) userNameDisplay.textContent = 'Entrar';
    
    const loggedOutMenu = document.getElementById('loggedOutMenu');
    const loggedInMenu = document.getElementById('loggedInMenu');
    
    if (loggedOutMenu) loggedOutMenu.classList.remove('hidden');
    if (loggedInMenu) loggedInMenu.classList.add('hidden');
}

function updateCartBadge() {
    const cart = JSON.parse(localStorage.getItem('petcare_cart') || '[]');
    const total = cart.reduce((sum, item) => sum + item.quantidade, 0);
    const badge = document.getElementById('cartBadge');
    if (badge) badge.textContent = total;
}

// Modal functions
function openLoginModal() {
    const modal = document.getElementById('loginModal');
    if (modal) {
        modal.classList.remove('hidden');
        modal.classList.add('flex');
    }
}

function closeLoginModal() {
    const modal = document.getElementById('loginModal');
    if (modal) {
        modal.classList.add('hidden');
        modal.classList.remove('flex');
    }
}

function openRegisterModal() {
    const modal = document.getElementById('registerModal');
    if (modal) {
        modal.classList.remove('hidden');
        modal.classList.add('flex');
    }
}

function closeRegisterModal() {
    const modal = document.getElementById('registerModal');
    if (modal) {
        modal.classList.add('hidden');
        modal.classList.remove('flex');
    }
}

// Toast and Status
function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = `toast ${type === 'success' ? 'bg-green-500' : type === 'error' ? 'bg-red-500' : 'bg-blue-500'} text-white px-5 py-3 rounded-xl shadow-lg flex items-center gap-2`;
    toast.innerHTML = `<i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i>${message}`;
    
    if (container) {
        container.appendChild(toast);
    } else {
        document.body.appendChild(toast);
    }
    
    setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

function showStatusMessage(message, type) {
    const statusDiv = document.getElementById('statusMessage');
    if (!statusDiv) return;
    
    const colors = {
        success: 'bg-green-100 text-green-700 border-l-4 border-green-500',
        error: 'bg-red-100 text-red-700 border-l-4 border-red-500',
        warning: 'bg-yellow-100 text-yellow-700 border-l-4 border-yellow-500',
        info: 'bg-blue-100 text-blue-700 border-l-4 border-blue-500'
    };
    
    statusDiv.className = `mb-6 p-4 rounded-xl shadow-md ${colors[type] || colors.info}`;
    statusDiv.innerHTML = `<i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'} mr-2"></i>${message}`;
    statusDiv.classList.remove('hidden');
    
    setTimeout(() => statusDiv.classList.add('hidden'), 5000);
}

// Event listeners
document.addEventListener('DOMContentLoaded', () => {
    initAuth();
    
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const email = document.getElementById('loginEmail').value;
            const senha = document.getElementById('loginPassword').value;
            login(email, senha);
        });
    }
    
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const nome = document.getElementById('regNome').value;
            const email = document.getElementById('regEmail').value;
            const senha = document.getElementById('regPassword').value;
            const confirm = document.getElementById('regConfirmPassword').value;
            register(nome, email, senha, confirm);
        });
    }
    
    const editProfileForm = document.getElementById('editProfileForm');
    if (editProfileForm) {
        editProfileForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const nome = document.getElementById('editNome').value;
            const email = document.getElementById('editEmail').value;
            const senha = document.getElementById('editSenha').value;
            updateProfile(nome, email, senha);
        });
    }
    
    // User dropdown
    const userMenuBtn = document.getElementById('userMenuBtn');
    const userDropdown = document.getElementById('userDropdown');
    
    if (userMenuBtn) {
        userMenuBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            if (userDropdown) userDropdown.classList.toggle('hidden');
        });
    }
    
    document.addEventListener('click', () => {
        if (userDropdown) userDropdown.classList.add('hidden');
    });
    
    if (userDropdown) {
        userDropdown.addEventListener('click', (e) => e.stopPropagation());
    }
});