package com.devsenai2a.petshop.controllers;

import com.devsenai2a.petshop.dto.LoginRequestDTO;
import com.devsenai2a.petshop.dto.LoginResponseDTO;
import com.devsenai2a.petshop.dto.RegisterRequestDTO;
import com.devsenai2a.petshop.entities.Usuario;
import com.devsenai2a.petshop.repositories.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequestDTO request) {
        System.out.println("🔐 Tentativa de login: " + request.getEmail());
        
        Usuario usuario = usuarioRepository.findByEmailAndSenha(request.getEmail(), request.getSenha());
        
        if (usuario == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(Map.of("error", "Email ou senha incorretos"));
        }
        
        String token = UUID.randomUUID().toString();
        
        LoginResponseDTO response = new LoginResponseDTO(
            usuario.getId(),
            usuario.getNome(),
            usuario.getEmail(),
            usuario.getRole(),
            token
        );
        
        return ResponseEntity.ok(response);
    }
    
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequestDTO request) {
        if (usuarioRepository.existsByEmail(request.getEmail())) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                .body(Map.of("error", "Email já cadastrado"));
        }
        
        Usuario usuario = new Usuario();
        usuario.setNome(request.getNome());
        usuario.setEmail(request.getEmail());
        usuario.setSenha(request.getSenha());
        usuario.setRole(request.getRole() != null ? request.getRole() : "USER");
        
        usuarioRepository.save(usuario);
        
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(Map.of("message", "Usuário cadastrado com sucesso"));
    }
    
    @GetMapping("/verificar")
    public ResponseEntity<?> verificarToken(@RequestHeader(value = "Authorization", required = false) String token) {
        if (token != null && token.startsWith("Bearer ")) {
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
    }
}