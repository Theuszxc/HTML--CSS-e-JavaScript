package com.devsenai2a.petshop.repositories;

import com.devsenai2a.petshop.entities.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    
    // Buscar usuário por email e senha (para login)
    Usuario findByEmailAndSenha(String email, String senha);
    
    // Buscar usuário por email
    Usuario findByEmail(String email);
    
    // Verificar se email já existe
    boolean existsByEmail(String email);
}