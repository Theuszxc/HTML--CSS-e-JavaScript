package com.devsenai2a.petshop.dto;

public class LoginResponseDTO {
    private Long id;
    private String nome;
    private String email;
    private String role;
    private String token;
    
    public LoginResponseDTO() {}
    
    public LoginResponseDTO(Long id, String nome, String email, String role, String token) {
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.role = role;
        this.token = token;
    }
    
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }
}