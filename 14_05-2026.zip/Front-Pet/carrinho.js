// ==================== CARRINHO COMPLETO ====================
let cartItems = [];
let appliedCoupon = null;
let currentUser = null;
let usersDB = [];
let ordersDB = [];

// Variáveis para o modal de quantidade
let pendingProduct = null;
let modalQuantity = 1;

const coupons = {
    'PET10': { discount: 10, type: 'percent', description: '10% de desconto' },
    'PET20': { discount: 20, type: 'percent', description: '20% de desconto' },
    'FREATEGRATIS': { discount: 15, type: 'fixed', description: 'R$15 de desconto' },
    'PETCARE50': { discount: 50, type: 'percent', description: '50% de desconto' }
};

// ==================== FUNÇÕES DO MODAL ====================
function openQuantityModal(product) {
    pendingProduct = product;
    modalQuantity = 1;
    
    document.getElementById('modalProductName').textContent = product.nome;
    document.getElementById('modalProductPrice').textContent = `R$ ${product.preco.toFixed(2)}`;
    document.getElementById('modalQuantity').textContent = modalQuantity;
    
    if (product.imagem) {
        document.getElementById('modalProductImage').src = product.imagem;
    } else {
        document.getElementById('modalProductImage').style.display = 'none';
    }
    
    document.getElementById('quantityModal').classList.add('active');
}

function closeQuantityModal() {
    document.getElementById('quantityModal').classList.remove('active');
    pendingProduct = null;
}

function incrementModalQuantity() {
    modalQuantity++;
    document.getElementById('modalQuantity').textContent = modalQuantity;
}

function decrementModalQuantity() {
    if (modalQuantity > 1) {
        modalQuantity--;
        document.getElementById('modalQuantity').textContent = modalQuantity;
    }
}

function confirmAddToCart() {
    if (pendingProduct) {
        addToCart(pendingProduct, modalQuantity);
        closeQuantityModal();
    }
}

// ==================== FUNÇÕES DO CARRINHO ====================
function addToCart(product, quantidade) {
    const existingItem = cartItems.find(item => item.id === product.id);
    
    if (existingItem) {
        existingItem.quantidade += quantidade;
        showToast(`${product.nome} - Quantidade atualizada para ${existingItem.quantidade}`, 'success');
    } else {
        cartItems.push({
            id: product.id,
            nome: product.nome,
            preco: product.preco,
            imagem: product.imagem,
            quantidade: quantidade
        });
        showToast(`${product.nome} adicionado ao carrinho!`, 'success');
    }
    
    saveCart();
    updateCartUI();
}

// Inicialização
function init() {
    loadUsers();
    loadOrders();
    loadSession();
    loadCart();
    updateUserInfo();
    updateCartUI();
}

function loadUsers() {
    const saved = localStorage.getItem('petcare_users');
    if (saved) {
        usersDB = JSON.parse(saved);
    } else {
        usersDB = [
            { id: 1, nome: "Administrador", email: "admin@petcare.com", senha: "admin123", role: "ADMIN", createdAt: new Date().toISOString() },
            { id: 2, nome: "João Silva", email: "joao@email.com", senha: "123456", role: "USER", createdAt: new Date().toISOString() }
        ];
        localStorage.setItem('petcare_users', JSON.stringify(usersDB));
    }
}

function loadOrders() {
    const saved = localStorage.getItem('petcare_orders');
    if (saved) {
        ordersDB = JSON.parse(saved);
    } else {
        ordersDB = [];
        localStorage.setItem('petcare_orders', JSON.stringify(ordersDB));
    }
}

function loadSession() {
    const savedSession = localStorage.getItem('petcare_session');
    if (savedSession) {
        try {
            const session = JSON.parse(savedSession);
            const user = usersDB.find(u => u.id === session.userId);
            if (user) {
                currentUser = { ...user, senha: undefined };
            }
        } catch(e) {}
    }
}

function loadCart() {
    const saved = localStorage.getItem('petcare_cart');
    if (saved) {
        try {
            cartItems = JSON.parse(saved);
        } catch(e) {
            cartItems = [];
        }
    }
}

function saveCart() {
    localStorage.setItem('petcare_cart', JSON.stringify(cartItems));
    updateCartBadge();
}

function updateCartBadge() {
    const total = cartItems.reduce((sum, item) => sum + item.quantidade, 0);
    const badges = document.querySelectorAll('#cartBadge');
    badges.forEach(badge => {
        if (badge) badge.textContent = total;
    });
}

function updateUserInfo() {
    const userInfo = document.getElementById('userInfo');
    const userNameSpan = document.getElementById('userName');
    
    if (currentUser) {
        userInfo.classList.remove('hidden');
        userNameSpan.textContent = currentUser.nome.split(' ')[0];
    } else {
        userInfo.classList.add('hidden');
    }
}

function updateCartUI() {
    const container = document.getElementById('cartItemsContainer');
    const cartItemCount = document.getElementById('cartItemCount');
    
    const totalItems = cartItems.reduce((sum, item) => sum + item.quantidade, 0);
    if (cartItemCount) cartItemCount.textContent = totalItems;
    
    if (!container) return;
    
    if (cartItems.length === 0) {
        container.innerHTML = `
            <div class="text-center py-16">
                <i class="fas fa-shopping-cart text-6xl text-gray-300 mb-4"></i>
                <p class="text-gray-500 text-lg">Seu carrinho está vazio</p>
                <a href="index.html" class="inline-block mt-4 bg-orange-500 text-white px-6 py-2 rounded-full hover:bg-orange-600 transition">
                    Continuar comprando
                </a>
            </div>
        `;
        updateOrderSummary();
        return;
    }
    
    container.innerHTML = cartItems.map((item, index) => `
        <div class="cart-item p-4 hover:bg-gray-50 transition" style="animation-delay: ${index * 0.05}s">
            <div class="flex gap-4">
                <div class="w-20 h-20 bg-gray-100 rounded-xl flex items-center justify-center">
                    ${item.imagem ? 
                        `<img src="${item.imagem}" class="w-full h-full object-contain p-2" onerror="this.src=''">` : 
                        `<i class="fas fa-box text-3xl text-gray-400"></i>`
                    }
                </div>
                <div class="flex-1">
                    <h3 class="font-bold text-gray-800">${escapeHtml(item.nome)}</h3>
                    <p class="text-orange-500 font-semibold">R$ ${item.preco.toFixed(2)}</p>
                    <div class="flex items-center gap-3 mt-2">
                        <button onclick="updateQuantity(${item.id}, ${item.quantidade - 1})" class="qty-btn w-7 h-7 rounded-full bg-gray-100 hover:bg-orange-500 hover:text-white transition flex items-center justify-center">
                            <i class="fas fa-minus text-xs"></i>
                        </button>
                        <span class="font-semibold w-8 text-center">${item.quantidade}</span>
                        <button onclick="updateQuantity(${item.id}, ${item.quantidade + 1})" class="qty-btn w-7 h-7 rounded-full bg-gray-100 hover:bg-orange-500 hover:text-white transition flex items-center justify-center">
                            <i class="fas fa-plus text-xs"></i>
                        </button>
                        <button onclick="removeFromCart(${item.id})" class="ml-auto text-red-400 hover:text-red-600 transition">
                            <i class="fas fa-trash-alt"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `).join('');
    
    updateOrderSummary();
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function updateOrderSummary() {
    const subtotal = cartItems.reduce((sum, item) => sum + (item.preco * item.quantidade), 0);
    let frete = subtotal > 100 ? 0 : 15.90;
    let discount = 0;
    
    if (appliedCoupon && coupons[appliedCoupon]) {
        const coupon = coupons[appliedCoupon];
        if (coupon.type === 'percent') {
            discount = subtotal * (coupon.discount / 100);
        } else {
            discount = coupon.discount;
        }
        if (discount > subtotal) discount = subtotal;
    }
    
    let total = subtotal + frete - discount;
    
    document.getElementById('subtotal').textContent = `R$ ${subtotal.toFixed(2)}`;
    document.getElementById('frete').textContent = frete === 0 ? 'Grátis' : `R$ ${frete.toFixed(2)}`;
    document.getElementById('total').textContent = `R$ ${total.toFixed(2)}`;
    
    const discountRow = document.getElementById('discountRow');
    const discountAmount = document.getElementById('discountAmount');
    
    if (discount > 0) {
        discountRow.classList.remove('hidden');
        discountAmount.textContent = `-R$ ${discount.toFixed(2)}`;
    } else {
        discountRow.classList.add('hidden');
    }
}

function updateQuantity(productId, newQuantity) {
    const index = cartItems.findIndex(item => item.id === productId);
    if (index !== -1) {
        if (newQuantity <= 0) {
            cartItems.splice(index, 1);
            showToast('Item removido do carrinho', 'info');
        } else {
            cartItems[index].quantidade = newQuantity;
        }
        saveCart();
        updateCartUI();
    }
}

function removeFromCart(productId) {
    cartItems = cartItems.filter(item => item.id !== productId);
    saveCart();
    updateCartUI();
    showToast('Item removido', 'info');
}

function clearCart() {
    if (cartItems.length > 0 && confirm('Tem certeza que deseja limpar todo o carrinho?')) {
        cartItems = [];
        appliedCoupon = null;
        const couponInput = document.getElementById('couponInput');
        const couponMessage = document.getElementById('couponMessage');
        if (couponInput) couponInput.value = '';
        if (couponMessage) couponMessage.innerHTML = '';
        saveCart();
        updateCartUI();
        showToast('Carrinho limpo', 'success');
    }
}

function applyCoupon() {
    const code = document.getElementById('couponInput').value.toUpperCase().trim();
    const messageDiv = document.getElementById('couponMessage');
    
    if (coupons[code]) {
        appliedCoupon = code;
        messageDiv.innerHTML = `<span class="text-green-600"><i class="fas fa-check-circle mr-1"></i> Cupom aplicado! ${coupons[code].description}</span>`;
        updateOrderSummary();
        showToast('Cupom aplicado com sucesso!', 'success');
    } else {
        messageDiv.innerHTML = `<span class="text-red-600"><i class="fas fa-exclamation-circle mr-1"></i> Cupom inválido!</span>`;
        setTimeout(() => {
            messageDiv.innerHTML = '';
        }, 3000);
    }
}

function proceedToCheckout() {
    if (!currentUser) {
        showToast('Faça login para finalizar a compra!', 'warning');
        setTimeout(() => window.location.href = 'index.html', 1500);
        return;
    }
    
    if (cartItems.length === 0) {
        showToast('Seu carrinho está vazio!', 'warning');
        return;
    }
    
    const total = parseFloat(document.getElementById('total').textContent.replace('R$ ', '').replace(',', '.'));
    
    // Salvar pedido
    const order = {
        id: ordersDB.length + 1,
        userId: currentUser.id,
        userName: currentUser.nome,
        items: cartItems.map(item => ({ ...item })),
        total: total,
        status: 'Pendente',
        createdAt: new Date().toISOString()
    };
    ordersDB.push(order);
    localStorage.setItem('petcare_orders', JSON.stringify(ordersDB));
    
    // Limpar carrinho
    cartItems = [];
    appliedCoupon = null;
    saveCart();
    updateCartUI();
    
    showToast(`Pedido #${order.id} finalizado com sucesso, ${currentUser.nome}!`, 'success');
    
    setTimeout(() => {
        window.location.href = 'index.html';
    }, 2000);
}

function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = `toast ${type === 'success' ? 'bg-green-500' : type === 'error' ? 'bg-red-500' : type === 'warning' ? 'bg-yellow-500' : 'bg-blue-500'} text-white px-5 py-3 rounded-xl shadow-lg flex items-center gap-2 mb-3`;
    const icon = type === 'success' ? 'fa-check-circle' : (type === 'error' ? 'fa-exclamation-circle' : (type === 'warning' ? 'fa-exclamation-triangle' : 'fa-info-circle'));
    toast.innerHTML = `<i class="fas ${icon}"></i><span>${message}</span>`;
    container.appendChild(toast);
    
    setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// ==================== FUNÇÃO PARA USAR EM OUTRAS PÁGINAS ====================
// Esta função deve ser chamada ao clicar em "Adicionar ao Carrinho" nos produtos
window.addToCartWithModal = function(product) {
    openQuantityModal(product);
};

// Eventos
document.addEventListener('DOMContentLoaded', () => {
    init();
    
    // Atualizar quando houver mudanças no storage
    window.addEventListener('storage', (e) => {
        if (e.key === 'petcare_cart') {
            loadCart();
            updateCartUI();
        }
        if (e.key === 'petcare_session') {
            loadSession();
            updateUserInfo();
        }
    });
});

// Funções globais para os botões
window.updateQuantity = updateQuantity;
window.removeFromCart = removeFromCart;
window.clearCart = clearCart;
window.applyCoupon = applyCoupon;
window.proceedToCheckout = proceedToCheckout;
window.openQuantityModal = openQuantityModal;
window.closeQuantityModal = closeQuantityModal;
window.incrementModalQuantity = incrementModalQuantity;
window.decrementModalQuantity = decrementModalQuantity;
window.confirmAddToCart = confirmAddToCart;