// Configuração da API
const PORTS = [8080, 8081];
let API_CATEGORIAS = 'http://localhost:8080/api/categorias';
let API_PRODUTOS = 'http://localhost:8080/api/produtos';
let backendDisponivel = false;
let categoriasList = [];
let currentView = 'produtos';
let allProdutosCache = [];

// ==================== CARRINHO ====================
let cartItems = [];

// Carregar carrinho do localStorage
function loadCartFromStorage() {
    const saved = localStorage.getItem('petcare_cart');
    if (saved) {
        try {
            cartItems = JSON.parse(saved);
            updateCartUI();
        } catch(e) {}
    }
}

// Salvar carrinho no localStorage
function saveCartToStorage() {
    localStorage.setItem('petcare_cart', JSON.stringify(cartItems));
}

// Abrir/fechar carrinho
function openCart() {
    document.getElementById('cartSidebar').classList.add('open');
    document.getElementById('cartOverlay').classList.add('active');
    document.body.style.overflow = 'hidden';
    updateCartUI();
}

function closeCart() {
    document.getElementById('cartSidebar').classList.remove('open');
    document.getElementById('cartOverlay').classList.remove('active');
    document.body.style.overflow = '';
}

// Adicionar ao carrinho
async function addToCart(productId, quantity = 1) {
    try {
        let produto;
        if (allProdutosCache.length > 0) {
            produto = allProdutosCache.find(p => p.id === productId);
        } else {
            const response = await fetch(`${API_PRODUTOS}/${productId}`);
            if (!response.ok) throw new Error('Produto não encontrado');
            produto = await response.json();
        }
        
        if (!produto) {
            showToast('Produto não encontrado!', 'error');
            return;
        }
        
        const existingIndex = cartItems.findIndex(item => item.id === productId);
        
        if (existingIndex !== -1) {
            cartItems[existingIndex].quantidade += quantity;
        } else {
            cartItems.push({
                id: produto.id,
                nome: produto.nome,
                preco: produto.precoDesconto || produto.preco,
                precoOriginal: produto.preco,
                imagem: produto.imagem,
                quantidade: quantity,
                estoque: produto.qtdEstoque || 0
            });
        }
        
        saveCartToStorage();
        updateCartUI();
        showToast(`${produto.nome} adicionado ao carrinho!`, 'success');
        
        // Animação no badge
        const badge = document.getElementById('cartBadge');
        if (badge) {
            badge.classList.add('pulse');
            setTimeout(() => badge.classList.remove('pulse'), 500);
        }
    } catch (error) {
        console.error('Erro ao adicionar ao carrinho:', error);
        showToast('Erro ao adicionar produto', 'error');
    }
}

// Atualizar quantidade
function updateCartItemQuantity(productId, newQuantity) {
    const index = cartItems.findIndex(item => item.id === productId);
    if (index !== -1) {
        if (newQuantity <= 0) {
            cartItems.splice(index, 1);
        } else {
            cartItems[index].quantidade = newQuantity;
        }
        saveCartToStorage();
        updateCartUI();
    }
}

// Remover item
function removeCartItem(productId) {
    cartItems = cartItems.filter(item => item.id !== productId);
    saveCartToStorage();
    updateCartUI();
    showToast('Item removido do carrinho', 'info');
}

// Limpar carrinho
function clearCart() {
    if (cartItems.length > 0 && confirm('Limpar todo o carrinho?')) {
        cartItems = [];
        saveCartToStorage();
        updateCartUI();
        showToast('Carrinho esvaziado', 'info');
    }
}

// Calcular total
function calculateTotal() {
    return cartItems.reduce((total, item) => total + (item.preco * item.quantidade), 0);
}

// Calcular economia
function calculateSavings() {
    return cartItems.reduce((total, item) => {
        if (item.precoOriginal && item.precoOriginal > item.preco) {
            return total + ((item.precoOriginal - item.preco) * item.quantidade);
        }
        return total;
    }, 0);
}

// Atualizar UI do carrinho
function updateCartUI() {
    const cartItemsContainer = document.getElementById('cartItems');
    const cartTotal = document.getElementById('cartTotal');
    const cartCount = document.getElementById('cartBadge');
    const cartSavings = document.getElementById('cartSavings');
    const cartDiscountDiv = document.getElementById('cartDiscountDiv');
    
    // Atualizar badge do carrinho
    const totalItems = cartItems.reduce((sum, item) => sum + item.quantidade, 0);
    if (cartCount) cartCount.textContent = totalItems;
    
    if (!cartItemsContainer) return;
    
    if (cartItems.length === 0) {
        cartItemsContainer.innerHTML = `
            <div class="empty-cart">
                <i class="fas fa-shopping-cart"></i>
                <p>Seu carrinho está vazio</p>
                <button onclick="closeCart()" class="mt-4 bg-orange-500 text-white px-4 py-2 rounded-lg">Continuar comprando</button>
            </div>
        `;
        if (cartTotal) cartTotal.textContent = 'R$ 0,00';
        if (cartDiscountDiv) cartDiscountDiv.style.display = 'none';
        return;
    }
    
    cartItemsContainer.innerHTML = cartItems.map(item => `
        <div class="cart-item">
            <div class="cart-item-img">
                ${item.imagem ? 
                    `<img src="${item.imagem}" onerror="this.src=''">` : 
                    `<i class="fas fa-box text-3xl text-gray-400"></i>`
                }
            </div>
            <div class="cart-item-info">
                <div class="cart-item-title">${item.nome}</div>
                <div class="cart-item-price">R$ ${item.preco.toFixed(2)}</div>
                <div class="cart-item-quantity">
                    <button class="qty-btn" onclick="updateCartItemQuantity(${item.id}, ${item.quantidade - 1})">-</button>
                    <span>${item.quantidade}</span>
                    <button class="qty-btn" onclick="updateCartItemQuantity(${item.id}, ${item.quantidade + 1})">+</button>
                </div>
            </div>
            <div class="remove-item" onclick="removeCartItem(${item.id})">
                <i class="fas fa-trash-alt"></i>
            </div>
        </div>
    `).join('');
    
    const total = calculateTotal();
    const savings = calculateSavings();
    
    if (cartTotal) cartTotal.textContent = `R$ ${total.toFixed(2)}`;
    
    if (savings > 0 && cartDiscountDiv) {
        cartDiscountDiv.style.display = 'block';
        if (cartSavings) cartSavings.textContent = `R$ ${savings.toFixed(2)}`;
    } else if (cartDiscountDiv) {
        cartDiscountDiv.style.display = 'none';
    }
}

// Finalizar compra
function checkout() {
    if (cartItems.length === 0) {
        showToast('Carrinho vazio!', 'warning');
        return;
    }
    
    const total = calculateTotal();
    const itemsList = cartItems.map(item => `${item.nome} (${item.quantidade}x)`).join(', ');
    
    alert(`✅ Pedido finalizado!\n\nItens: ${itemsList}\nTotal: R$ ${total.toFixed(2)}\n\nObrigado pela compra!`);
    
    cartItems = [];
    saveCartToStorage();
    updateCartUI();
    closeCart();
    showToast('Compra finalizada com sucesso!', 'success');
}

// Show toast
function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = 'toast-cart';
    const icon = type === 'success' ? 'fa-check-circle' : (type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle');
    toast.innerHTML = `<i class="fas ${icon}"></i><span>${message}</span>`;
    document.body.appendChild(toast);
    setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Testar backend
async function testarBackend() {
    for (const porta of PORTS) {
        try {
            const url = `http://localhost:${porta}/api/categorias`;
            const response = await fetch(url, { 
                method: 'GET', 
                headers: { 'Content-Type': 'application/json' } 
            });
            if (response.ok) {
                API_CATEGORIAS = `http://localhost:${porta}/api/categorias`;
                API_PRODUTOS = `http://localhost:${porta}/api/produtos`;
                backendDisponivel = true;
                showStatus(`✅ Conectado ao backend na porta ${porta}`, 'green');
                return true;
            }
        } catch (error) {}
    }
    showStatus('⚠️ Backend não encontrado - Modo demonstração', 'yellow');
    return false;
}

// Tabs
function showTab(tab) {
    if (tab === 'produtos') {
        document.getElementById('produtosSection').classList.remove('hidden');
        document.getElementById('produtoDetailSection').classList.add('hidden');
        document.getElementById('categoriasSection').classList.add('hidden');
        document.getElementById('tabProdutos').classList.add('tab-active');
        document.getElementById('tabCategorias').classList.remove('tab-active');
        currentView = 'produtos';
        loadProdutos();
    } else {
        document.getElementById('produtosSection').classList.add('hidden');
        document.getElementById('produtoDetailSection').classList.add('hidden');
        document.getElementById('categoriasSection').classList.remove('hidden');
        document.getElementById('tabProdutos').classList.remove('tab-active');
        document.getElementById('tabCategorias').classList.add('tab-active');
        currentView = 'categorias';
        loadCategories();
    }
}

function backToProducts() {
    document.getElementById('produtosSection').classList.remove('hidden');
    document.getElementById('produtoDetailSection').classList.add('hidden');
    currentView = 'produtos';
    loadProdutos();
}

// ==================== PRODUTOS ====================
async function loadProdutos() {
    if (!backendDisponivel) await testarBackend();
    
    try {
        const response = await fetch(API_PRODUTOS);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const produtos = await response.json();
        allProdutosCache = produtos;
        displayProdutos(produtos);
    } catch (error) {
        document.getElementById('produtosGrid').innerHTML = `
            <div class="col-span-full text-center py-8">
                <i class="fas fa-plug text-6xl text-red-400 mb-4"></i>
                <p class="text-red-600 font-bold">Erro de conexão!</p>
                <button onclick="testarBackend(); loadProdutos();" class="mt-4 bg-orange-500 text-white px-4 py-2 rounded-lg">
                    <i class="fas fa-sync-alt mr-2"></i>Tentar novamente
                </button>
            </div>
        `;
    }
}

function getStockClass(quantity) {
    if (quantity > 20) return 'stock-high';
    if (quantity > 5) return 'stock-medium';
    return 'stock-low';
}

function displayProdutos(produtos) {
    const grid = document.getElementById('produtosGrid');
    if (!produtos || produtos.length === 0) {
        grid.innerHTML = '<div class="col-span-full text-center py-8">Nenhum produto cadastrado</div>';
        return;
    }
    grid.innerHTML = produtos.map(p => {
        const desconto = p.precoDesconto && p.precoDesconto < p.preco;
        const percentual = desconto ? Math.round(((p.preco - p.precoDesconto) / p.preco) * 100) : 0;
        const qtdEstoque = p.qtdEstoque || 0;
        return `
        <div class="product-card bg-white rounded-xl shadow-sm hover:shadow-xl overflow-hidden group" onclick="showProductDetail(${p.id})">
            <div class="relative">
                ${desconto ? `<div class="absolute top-2 left-2 bg-red-500 text-white px-2 py-1 rounded-md text-xs font-bold z-10">${percentual}% OFF</div>` : ''}
                <div class="bg-gray-100 p-6 flex items-center justify-center h-48">
                    ${p.imagem ? `<img src="${p.imagem}" class="h-32 object-contain group-hover:scale-110 transition" onerror="this.src=''">` : `<i class="fas fa-box text-6xl text-gray-400"></i>`}
                </div>
            </div>
            <div class="p-4">
                <h3 class="font-semibold text-gray-800 mb-2">${p.nome}</h3>
                <p class="text-xs text-gray-500 mb-2">${p.categoria?.nome || 'Sem categoria'}</p>
                <div class="flex items-baseline gap-2 mb-3">
                    <span class="text-2xl font-bold text-orange-500">R$ ${(p.precoDesconto || p.preco).toFixed(2)}</span>
                    ${p.precoDesconto ? `<span class="text-sm text-gray-400 line-through">R$ ${p.preco.toFixed(2)}</span>` : ''}
                </div>
                <button onclick="event.stopPropagation(); addToCart(${p.id})" class="w-full bg-orange-500 text-white py-2 rounded-lg font-semibold hover:bg-orange-600 transition flex items-center justify-center gap-2">
                    <i class="fas fa-shopping-cart"></i> Comprar
                </button>
            </div>
        </div>`;
    }).join('');
}

async function showProductDetail(productId) {
    if (!backendDisponivel) await testarBackend();
    try {
        const response = await fetch(`${API_PRODUTOS}/${productId}`);
        if (!response.ok) throw new Error('Produto não encontrado');
        const produto = await response.json();
        
        renderProductDetail(produto);
        
        document.getElementById('produtosSection').classList.add('hidden');
        document.getElementById('produtoDetailSection').classList.remove('hidden');
        document.getElementById('categoriasSection').classList.add('hidden');
        currentView = 'detalhe';
    } catch (error) {
        showStatus('❌ Erro ao carregar detalhes', 'red');
    }
}

function renderProductDetail(produto) {
    const desconto = produto.precoDesconto && produto.precoDesconto < produto.preco;
    const percentual = desconto ? Math.round(((produto.preco - produto.precoDesconto) / produto.preco) * 100) : 0;
    const qtdEstoque = produto.qtdEstoque || 0;
    const hasStock = qtdEstoque > 0;
    
    const detailHtml = `
        <div class="grid md:grid-cols-2 gap-8 p-6 md:p-8">
            <div class="bg-gray-100 rounded-2xl flex items-center justify-center p-8">
                ${produto.imagem ? 
                    `<img src="${produto.imagem}" class="product-detail-img max-h-96 w-full object-contain rounded-xl" onerror="this.src=''">` : 
                    `<i class="fas fa-box-open text-8xl text-gray-400"></i>`
                }
            </div>
            <div class="space-y-5">
                <div>
                    <h1 class="text-3xl md:text-4xl font-bold text-gray-800">${produto.nome}</h1>
                    ${produto.categoria ? `<p class="text-orange-500 mt-1"><i class="fas fa-tag mr-1"></i>${produto.categoria.nome}</p>` : ''}
                </div>
                
                <div class="border-t border-b py-4">
                    <div class="flex items-baseline gap-3">
                        <span class="text-3xl font-bold text-orange-500">R$ ${(produto.precoDesconto || produto.preco).toFixed(2)}</span>
                        ${produto.precoDesconto ? `<span class="text-lg text-gray-400 line-through">R$ ${produto.preco.toFixed(2)}</span>` : ''}
                        ${desconto ? `<span class="bg-red-100 text-red-600 px-2 py-1 rounded-md text-sm font-bold">-${percentual}%</span>` : ''}
                    </div>
                </div>
                
                <div>
                    <h3 class="font-semibold text-gray-700 mb-2">📝 Descrição</h3>
                    <p class="text-gray-600">${produto.descricao || 'Sem descrição detalhada.'}</p>
                </div>
                
                <div class="bg-gray-50 rounded-xl p-4">
                    <div class="flex justify-between mb-2">
                        <span class="text-gray-600">Estoque:</span>
                        <span class="font-semibold ${qtdEstoque > 0 ? 'text-green-600' : 'text-red-600'}">${qtdEstoque} unidades</span>
                    </div>
                </div>
                
                <button onclick="addToCart(${produto.id})" class="w-full ${!hasStock ? 'bg-gray-400 cursor-not-allowed' : 'bg-gradient-to-r from-orange-500 to-amber-600 hover:shadow-lg'} text-white font-bold py-3 rounded-xl transition flex items-center justify-center gap-2" ${!hasStock ? 'disabled' : ''}>
                    <i class="fas fa-shopping-cart"></i> ${hasStock ? 'Adicionar ao Carrinho' : 'Indisponível'}
                </button>
                <button onclick="backToProducts()" class="w-full border-2 border-orange-300 text-orange-600 py-3 rounded-xl hover:bg-orange-50 transition font-semibold">
                    ← Continuar comprando
                </button>
            </div>
        </div>
    `;
    document.getElementById('produtoDetailContent').innerHTML = detailHtml;
}

// ==================== CATEGORIAS ====================
async function loadCategories() {
    if (!backendDisponivel) await testarBackend();
    try {
        const response = await fetch(API_CATEGORIAS);
        if (!response.ok) throw new Error();
        const categories = await response.json();
        displayCategories(categories);
        displayAdminList(categories);
    } catch (error) {
        document.getElementById('categoriesGrid').innerHTML = `<div class="col-span-full text-center py-8">Erro ao carregar</div>`;
    }
}

function displayCategories(categories) {
    const grid = document.getElementById('categoriesGrid');
    if (!categories || categories.length === 0) {
        grid.innerHTML = '<div class="col-span-full text-center py-8">Nenhuma categoria</div>';
        return;
    }
    grid.innerHTML = categories.filter(c => c.ativo).map(c => `
        <div class="category-card bg-white rounded-xl shadow-sm p-5 text-center hover:shadow-md transition">
            <div class="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <i class="fas ${c.icon || 'fa-paw'} text-orange-500 text-2xl"></i>
            </div>
            <span class="font-semibold text-gray-700">${c.nome}</span>
        </div>
    `).join('');
}

function displayAdminList(categories) {
    const list = document.getElementById('adminList');
    if (!categories || categories.length === 0) {
        list.innerHTML = '<div class="text-center py-8">Nenhuma categoria</div>';
        return;
    }
    list.innerHTML = categories.map(c => `
        <div class="bg-gray-50 rounded-lg p-4 flex justify-between items-center">
            <div><h4 class="font-semibold">${c.nome}</h4>${c.descricao ? `<p class="text-sm text-gray-600">${c.descricao}</p>` : ''}</div>
            <div class="flex gap-2"><button onclick="editCategory(${c.id})" class="bg-blue-500 text-white px-3 py-1 rounded"><i class="fas fa-edit"></i></button><button onclick="deleteCategory(${c.id})" class="bg-red-500 text-white px-3 py-1 rounded"><i class="fas fa-trash"></i></button></div>
        </div>
    `).join('');
}

// ==================== CRUD ====================
async function loadCategoriasForSelect() {
    try {
        const response = await fetch(API_CATEGORIAS);
        if (response.ok) {
            categoriasList = await response.json();
            const select = document.getElementById('produtoCategoriaId');
            select.innerHTML = '<option value="">Selecione</option>' + categoriasList.filter(c => c.ativo).map(c => `<option value="${c.id}">${c.nome}</option>`).join('');
        }
    } catch (error) {}
}

function openProdutoModal(produto = null) {
    loadCategoriasForSelect();
    if (produto) {
        document.getElementById('produtoModalTitle').innerText = 'Editar Produto';
        document.getElementById('produtoId').value = produto.id;
        document.getElementById('produtoNome').value = produto.nome;
        document.getElementById('produtoDescricao').value = produto.descricao || '';
        document.getElementById('produtoPreco').value = produto.preco;
        document.getElementById('produtoPrecoDesconto').value = produto.precoDesconto || '';
        document.getElementById('produtoQtdEstoque').value = produto.qtdEstoque || 0;
        document.getElementById('produtoImagem').value = produto.imagem || '';
        document.getElementById('produtoCategoriaId').value = produto.categoria?.id || '';
        document.getElementById('produtoAtivo').checked = produto.ativo;
    } else {
        document.getElementById('produtoModalTitle').innerText = 'Novo Produto';
        document.getElementById('produtoForm').reset();
        document.getElementById('produtoId').value = '';
        document.getElementById('produtoAtivo').checked = true;
    }
    document.getElementById('produtoModal').classList.remove('hidden');
    document.getElementById('produtoModal').classList.add('flex');
}

function closeProdutoModal() {
    document.getElementById('produtoModal').classList.add('hidden');
    document.getElementById('produtoModal').classList.remove('flex');
}

async function saveProduto(event) {
    event.preventDefault();
    const id = document.getElementById('produtoId').value;
    const produto = {
        nome: document.getElementById('produtoNome').value,
        descricao: document.getElementById('produtoDescricao').value,
        preco: parseFloat(document.getElementById('produtoPreco').value),
        precoDesconto: parseFloat(document.getElementById('produtoPrecoDesconto').value) || null,
        qtdEstoque: parseInt(document.getElementById('produtoQtdEstoque').value) || 0,
        imagem: document.getElementById('produtoImagem').value,
        ativo: document.getElementById('produtoAtivo').checked,
        categoria: document.getElementById('produtoCategoriaId').value ? { id: parseInt(document.getElementById('produtoCategoriaId').value) } : null
    };

    try {
        const url = id ? `${API_PRODUTOS}/${id}` : API_PRODUTOS;
        const method = id ? 'PUT' : 'POST';
        const response = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(produto) });
        if (response.ok) {
            showStatus(id ? '✅ Produto atualizado!' : '✅ Produto criado!', 'green');
            closeProdutoModal();
            loadProdutos();
        } else showStatus('❌ Erro ao salvar', 'red');
    } catch (error) { showStatus('❌ Erro de conexão', 'red'); }
}

async function editProduto(id) {
    try {
        const response = await fetch(`${API_PRODUTOS}/${id}`);
        if (response.ok) openProdutoModal(await response.json());
    } catch (error) {}
}

async function deleteProduto(id) {
    if (confirm('Excluir este produto?')) {
        try {
            await fetch(`${API_PRODUTOS}/${id}`, { method: 'DELETE' });
            showStatus('✅ Produto excluído!', 'green');
            loadProdutos();
        } catch (error) {}
    }
}

async function createCategory(event) {
    event.preventDefault();
    const data = { nome: document.getElementById('nome').value, descricao: document.getElementById('descricao').value, icon: document.getElementById('icon').value, ativo: document.getElementById('ativo').checked };
    try {
        const response = await fetch(API_CATEGORIAS, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
        if (response.ok) {
            showStatus('✅ Categoria criada!', 'green');
            document.getElementById('categoryForm').reset();
            loadCategories();
        }
    } catch (error) {}
}

async function editCategory(id) {
    const newName = prompt('Novo nome:');
    if (newName?.trim()) {
        await fetch(`${API_CATEGORIAS}/${id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ nome: newName }) });
        loadCategories();
    }
}

async function deleteCategory(id) {
    if (confirm('Excluir categoria?')) {
        await fetch(`${API_CATEGORIAS}/${id}`, { method: 'DELETE' });
        loadCategories();
    }
}

function showStatus(msg, color) {
    const div = document.getElementById('status');
    div.className = `mb-4 p-3 rounded-lg ${color === 'green' ? 'bg-green-100 text-green-700' : color === 'yellow' ? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-700'}`;
    div.innerHTML = `<i class="fas ${color === 'green' ? 'fa-check-circle' : 'fa-exclamation-circle'} mr-2"></i>${msg}`;
    div.classList.remove('hidden');
    setTimeout(() => div.classList.add('hidden'), 5000);
}

function openModal() { document.getElementById('adminModal').classList.remove('hidden'); document.getElementById('adminModal').classList.add('flex'); }
function closeModal() { document.getElementById('adminModal').classList.add('hidden'); document.getElementById('adminModal').classList.remove('flex'); }

// Event Listeners
document.addEventListener('DOMContentLoaded', async () => {
    loadCartFromStorage();
    await testarBackend();
    showTab('produtos');
    document.getElementById('categoryForm').addEventListener('submit', createCategory);
    document.getElementById('produtoForm').addEventListener('submit', saveProduto);
    document.getElementById('adminButton').onclick = openModal;
    document.getElementById('adminProdutoButton').onclick = () => openProdutoModal(null);
    
    document.getElementById('searchInput').addEventListener('input', async (e) => {
        if (currentView !== 'produtos') return;
        const term = e.target.value.toLowerCase();
        const filtered = allProdutosCache.filter(p => p.nome.toLowerCase().includes(term));
        displayProdutos(filtered);
    });
});

window.onclick = (e) => { 
    if (e.target === document.getElementById('adminModal')) closeModal();
    if (e.target === document.getElementById('produtoModal')) closeProdutoModal();
    if (e.target === document.getElementById('cartOverlay')) closeCart();
};