// Configuração da API
const PORTS = [8080, 8081];
let API_CATEGORIAS = 'http://localhost:8080/api/categorias';
let API_PRODUTOS = 'http://localhost:8080/api/produtos';
let backendDisponivel = false;
let categoriasList = [];
let currentView = 'produtos';
let allProdutosCache = [];

// Função para testar qual porta está funcionando
async function testarBackend() {
    for (const porta of PORTS) {
        try {
            const url = `http://localhost:${porta}/api/categorias`;
            console.log(`Testando conexão em: ${url}`);
            const response = await fetch(url, { 
                method: 'GET', 
                headers: { 'Content-Type': 'application/json' } 
            });
            if (response.ok) {
                API_CATEGORIAS = `http://localhost:${porta}/api/categorias`;
                API_PRODUTOS = `http://localhost:${porta}/api/produtos`;
                backendDisponivel = true;
                console.log(`✅ Backend encontrado na porta ${porta}`);
                showStatus(`✅ Conectado ao backend na porta ${porta}`, 'green');
                return true;
            }
        } catch (error) {
            console.log(`Porta ${porta} não está respondendo`);
        }
    }
    showStatus('❌ Backend não encontrado! Verifique se o Spring Boot está rodando', 'red');
    return false;
}

// Tabs
function showTab(tab) {
    if (tab === 'produtos') {
        document.getElementById('produtosSection').classList.remove('hidden');
        document.getElementById('produtoDetailSection').classList.add('hidden');
        document.getElementById('categoriasSection').classList.add('hidden');
        document.getElementById('tabProdutos').classList.add('tab-active');
        document.getElementById('tabCategorias').classList.remove('tab-active');
        currentView = 'produtos';
        loadProdutos();
    } else {
        document.getElementById('produtosSection').classList.add('hidden');
        document.getElementById('produtoDetailSection').classList.add('hidden');
        document.getElementById('categoriasSection').classList.remove('hidden');
        document.getElementById('tabProdutos').classList.remove('tab-active');
        document.getElementById('tabCategorias').classList.add('tab-active');
        currentView = 'categorias';
        loadCategories();
    }
}

// Função para voltar à lista de produtos
function backToProducts() {
    document.getElementById('produtosSection').classList.remove('hidden');
    document.getElementById('produtoDetailSection').classList.add('hidden');
    currentView = 'produtos';
    loadProdutos();
}

// ==================== PRODUTOS ====================
async function loadProdutos() {
    if (!backendDisponivel) {
        await testarBackend();
    }
    
    try {
        console.log('Carregando produtos de:', API_PRODUTOS);
        const response = await fetch(API_PRODUTOS);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const produtos = await response.json();
        allProdutosCache = produtos;
        console.log('Produtos carregados:', produtos);
        displayProdutos(produtos);
    } catch (error) {
        console.error('Erro ao carregar produtos:', error);
        document.getElementById('produtosGrid').innerHTML = `
            <div class="col-span-full text-center py-8">
                <i class="fas fa-plug text-6xl text-red-400 mb-4"></i>
                <p class="text-red-600 font-bold">Erro de conexão!</p>
                <p class="text-gray-500 mt-2">Backend não está respondendo em: ${API_PRODUTOS}</p>
                <button onclick="testarBackend(); loadProdutos();" class="mt-4 bg-orange-500 text-white px-4 py-2 rounded-lg hover:bg-orange-600">
                    <i class="fas fa-sync-alt mr-2"></i>Tentar novamente
                </button>
            </div>
        `;
    }
}

function getStockClass(quantity) {
    if (quantity > 20) return 'stock-high';
    if (quantity > 5) return 'stock-medium';
    return 'stock-low';
}

function getStockText(quantity) {
    if (quantity > 20) return '✅ Estoque alto';
    if (quantity > 5) return '⚠️ Estoque médio';
    if (quantity > 0) return '🔴 Estoque baixo';
    return '❌ Sem estoque';
}

function displayProdutos(produtos) {
    const grid = document.getElementById('produtosGrid');
    if (!produtos || produtos.length === 0) {
        grid.innerHTML = '<div class="col-span-full text-center py-8">Nenhum produto cadastrado</div>';
        return;
    }
    grid.innerHTML = produtos.map(p => {
        const desconto = p.precoDesconto && p.precoDesconto < p.preco;
        const percentual = desconto ? Math.round(((p.preco - p.precoDesconto) / p.preco) * 100) : 0;
        const qtdEstoque = p.qtdEstoque || 0;
        return `
        <div class="product-card bg-white rounded-xl shadow-sm hover:shadow-xl overflow-hidden group" onclick="showProductDetail(${p.id})">
            <div class="relative">
                ${desconto ? `<div class="absolute top-2 left-2 bg-red-500 text-white px-2 py-1 rounded-md text-xs font-bold z-10">${percentual}% OFF</div>` : ''}
                <div class="bg-gray-100 p-6 flex items-center justify-center h-48">
                    ${p.imagem ? `<img src="${p.imagem}" class="h-32 object-contain group-hover:scale-110 transition" onerror="this.src=''">` : `<i class="fas fa-box text-6xl text-gray-400 group-hover:scale-110 transition"></i>`}
                </div>
            </div>
            <div class="p-4">
                <h3 class="font-semibold text-gray-800 mb-2">${p.nome}</h3>
                <p class="text-xs text-gray-500 mb-2">${p.categoria?.nome || 'Sem categoria'}</p>
                <div class="flex items-baseline gap-2 mb-3">
                    <span class="text-2xl font-bold text-orange-500">R$ ${(p.precoDesconto || p.preco).toFixed(2)}</span>
                    ${p.precoDesconto ? `<span class="text-sm text-gray-400 line-through">R$ ${p.preco.toFixed(2)}</span>` : ''}
                </div>
                <div class="mb-2">
                    <span class="stock-badge ${getStockClass(qtdEstoque)}">${getStockText(qtdEstoque)} (${qtdEstoque} un.)</span>
                </div>
                <div class="flex gap-2 mt-2">
                    <button onclick="event.stopPropagation(); editProduto(${p.id})" class="flex-1 bg-blue-500 text-white py-2 rounded-lg font-semibold hover:bg-blue-600 transition"><i class="fas fa-edit"></i> Editar</button>
                    <button onclick="event.stopPropagation(); deleteProduto(${p.id})" class="flex-1 bg-red-500 text-white py-2 rounded-lg font-semibold hover:bg-red-600 transition"><i class="fas fa-trash"></i> Excluir</button>
                </div>
            </div>
        </div>`;
    }).join('');
}

// Função principal: Exibir página de descrição do produto com base no ID
async function showProductDetail(productId) {
    if (!backendDisponivel) await testarBackend();
    try {
        const response = await fetch(`${API_PRODUTOS}/${productId}`);
        if (!response.ok) throw new Error('Produto não encontrado');
        const produto = await response.json();
        
        renderProductDetail(produto);
        
        document.getElementById('produtosSection').classList.add('hidden');
        document.getElementById('produtoDetailSection').classList.remove('hidden');
        document.getElementById('categoriasSection').classList.add('hidden');
        currentView = 'detalhe';
    } catch (error) {
        console.error('Erro ao carregar detalhes do produto:', error);
        showStatus('❌ Erro ao carregar detalhes do produto', 'red');
    }
}

function renderProductDetail(produto) {
    const desconto = produto.precoDesconto && produto.precoDesconto < produto.preco;
    const percentual = desconto ? Math.round(((produto.preco - produto.precoDesconto) / produto.preco) * 100) : 0;
    const qtdEstoque = produto.qtdEstoque || 0;
    const hasStock = qtdEstoque > 0;
    
    const detailHtml = `
        <div class="grid md:grid-cols-2 gap-8 p-6 md:p-8">
            <div class="bg-gray-100 rounded-2xl flex items-center justify-center p-8">
                ${produto.imagem ? 
                    `<img src="${produto.imagem}" class="product-detail-img max-h-96 w-full object-contain rounded-xl" onerror="this.src=''">` : 
                    `<i class="fas fa-box-open text-8xl text-gray-400"></i>`
                }
            </div>
            <div class="space-y-5">
                <div>
                    <div class="flex items-center gap-2 mb-2 flex-wrap">
                        ${produto.categoria ? `<span class="bg-orange-100 text-orange-700 px-3 py-1 rounded-full text-sm font-semibold"><i class="fas fa-tag mr-1"></i>${produto.categoria.nome}</span>` : ''}
                        <span class="stock-badge ${getStockClass(qtdEstoque)}">${getStockText(qtdEstoque)}</span>
                    </div>
                    <h1 class="text-3xl md:text-4xl font-bold text-gray-800">${produto.nome}</h1>
                </div>
                
                <div class="border-t border-b py-4">
                    <div class="flex items-baseline gap-3">
                        <span class="text-3xl font-bold text-orange-500">R$ ${(produto.precoDesconto || produto.preco).toFixed(2)}</span>
                        ${produto.precoDesconto ? `<span class="text-lg text-gray-400 line-through">R$ ${produto.preco.toFixed(2)}</span>` : ''}
                        ${desconto ? `<span class="bg-red-100 text-red-600 px-2 py-1 rounded-md text-sm font-bold">-${percentual}%</span>` : ''}
                    </div>
                    <p class="text-sm text-gray-500 mt-1">Em até 3x sem juros</p>
                </div>
                
                <div>
                    <h3 class="font-semibold text-gray-700 mb-2">📝 Descrição</h3>
                    <p class="text-gray-600 leading-relaxed">${produto.descricao || 'Sem descrição detalhada para este produto.'}</p>
                </div>
                
                <div class="bg-gray-50 rounded-xl p-4 space-y-2">
                    <div class="flex justify-between">
                        <span class="text-gray-600"><i class="fas fa-boxes mr-2"></i>Estoque disponível:</span>
                        <span class="font-semibold ${qtdEstoque > 0 ? 'text-green-600' : 'text-red-600'}">${qtdEstoque} unidades</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-600"><i class="fas fa-barcode mr-2"></i>Código:</span>
                        <span class="font-mono text-sm">#${produto.id}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-600"><i class="fas fa-calendar-alt mr-2"></i>Status:</span>
                        <span class="${produto.ativo ? 'text-green-600' : 'text-red-600'}">${produto.ativo ? 'Ativo' : 'Inativo'}</span>
                    </div>
                </div>
                
                <div class="flex gap-4 pt-4">
                    <button onclick="addToCart(${produto.id})" class="flex-1 ${!hasStock ? 'bg-gray-400 cursor-not-allowed' : 'btn-primary'} text-white font-bold py-3 rounded-xl transition flex items-center justify-center gap-2" ${!hasStock ? 'disabled' : ''}>
                        <i class="fas fa-shopping-cart"></i> ${hasStock ? 'Comprar agora' : 'Indisponível'}
                    </button>
                    <button onclick="backToProducts()" class="px-6 py-3 border border-orange-300 text-orange-600 rounded-xl hover:bg-orange-50 transition font-semibold">
                        ← Voltar
                    </button>
                </div>
                ${hasStock ? `<p class="text-xs text-gray-400 text-center mt-3"><i class="fas fa-truck"></i> Entrega rápida para sua região</p>` : ''}
            </div>
        </div>
    `;
    document.getElementById('produtoDetailContent').innerHTML = detailHtml;
}

function addToCart(productId) {
    showStatus('🛒 Produto adicionado ao carrinho!', 'green');
}

async function loadCategoriasForSelect() {
    try {
        const response = await fetch(API_CATEGORIAS);
        if (response.ok) {
            categoriasList = await response.json();
            const select = document.getElementById('produtoCategoriaId');
            select.innerHTML = '<option value="">Selecione uma categoria</option>' + 
                categoriasList.filter(c => c.ativo).map(c => `<option value="${c.id}">${c.nome}</option>`).join('');
        }
    } catch (error) {
        console.error('Erro ao carregar categorias para select:', error);
    }
}

function openProdutoModal(produto = null) {
    loadCategoriasForSelect();
    if (produto) {
        document.getElementById('produtoModalTitle').innerText = 'Editar Produto';
        document.getElementById('produtoId').value = produto.id;
        document.getElementById('produtoNome').value = produto.nome;
        document.getElementById('produtoDescricao').value = produto.descricao || '';
        document.getElementById('produtoPreco').value = produto.preco;
        document.getElementById('produtoPrecoDesconto').value = produto.precoDesconto || '';
        document.getElementById('produtoQtdEstoque').value = produto.qtdEstoque || 0;
        document.getElementById('produtoImagem').value = produto.imagem || '';
        document.getElementById('produtoCategoriaId').value = produto.categoria?.id || '';
        document.getElementById('produtoAtivo').checked = produto.ativo;
    } else {
        document.getElementById('produtoModalTitle').innerText = 'Novo Produto';
        document.getElementById('produtoForm').reset();
        document.getElementById('produtoId').value = '';
        document.getElementById('produtoAtivo').checked = true;
    }
    document.getElementById('produtoModal').classList.remove('hidden');
    document.getElementById('produtoModal').classList.add('flex');
}

function closeProdutoModal() {
    document.getElementById('produtoModal').classList.add('hidden');
    document.getElementById('produtoModal').classList.remove('flex');
}

async function saveProduto(event) {
    event.preventDefault();
    const id = document.getElementById('produtoId').value;
    const produto = {
        nome: document.getElementById('produtoNome').value,
        descricao: document.getElementById('produtoDescricao').value,
        preco: parseFloat(document.getElementById('produtoPreco').value),
        precoDesconto: parseFloat(document.getElementById('produtoPrecoDesconto').value) || null,
        qtdEstoque: parseInt(document.getElementById('produtoQtdEstoque').value) || 0,
        imagem: document.getElementById('produtoImagem').value,
        ativo: document.getElementById('produtoAtivo').checked,
        categoria: document.getElementById('produtoCategoriaId').value ? { id: parseInt(document.getElementById('produtoCategoriaId').value) } : null
    };

    try {
        const url = id ? `${API_PRODUTOS}/${id}` : API_PRODUTOS;
        const method = id ? 'PUT' : 'POST';
        const response = await fetch(url, {
            method: method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(produto)
        });
        
        if (response.ok) {
            showStatus(id ? '✅ Produto atualizado!' : '✅ Produto criado!', 'green');
            closeProdutoModal();
            if (currentView === 'produtos' || currentView === 'detalhe') {
                loadProdutos();
                if (currentView === 'detalhe') backToProducts();
            }
        } else {
            showStatus(`❌ Erro ao salvar: ${response.status}`, 'red');
        }
    } catch (error) {
        console.error('Erro fetch:', error);
        showStatus('❌ Erro de conexão: ' + error.message, 'red');
    }
}

async function editProduto(id) {
    try {
        const response = await fetch(`${API_PRODUTOS}/${id}`);
        if (response.ok) {
            const produto = await response.json();
            openProdutoModal(produto);
        } else {
            showStatus('❌ Erro ao carregar produto', 'red');
        }
    } catch (error) {
        console.error('Erro:', error);
        showStatus('❌ Erro ao carregar produto', 'red');
    }
}

async function deleteProduto(id) {
    if (confirm('Tem certeza que deseja excluir este produto?')) {
        try {
            const response = await fetch(`${API_PRODUTOS}/${id}`, { method: 'DELETE' });
            if (response.ok) {
                showStatus('✅ Produto excluído!', 'green');
                if (currentView === 'produtos') loadProdutos();
                else if (currentView === 'detalhe') backToProducts();
            } else {
                showStatus('❌ Erro ao excluir', 'red');
            }
        } catch (error) {
            console.error('Erro:', error);
            showStatus('❌ Erro ao excluir: ' + error.message, 'red');
        }
    }
}

// ==================== CATEGORIAS ====================
async function loadCategories() {
    if (!backendDisponivel) await testarBackend();
    try {
        const response = await fetch(API_CATEGORIAS);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const categories = await response.json();
        displayCategories(categories);
        displayAdminList(categories);
    } catch (error) {
        console.error('Erro ao carregar categorias:', error);
        document.getElementById('categoriesGrid').innerHTML = `<div class="col-span-full text-center py-8">Erro de conexão</div>`;
    }
}

function displayCategories(categories) {
    const grid = document.getElementById('categoriesGrid');
    if (!categories || categories.length === 0) {
        grid.innerHTML = '<div class="col-span-full text-center py-8">Nenhuma categoria cadastrada</div>';
        return;
    }
    grid.innerHTML = categories.filter(c => c.ativo).map(c => `
        <div class="category-card bg-white rounded-xl shadow-sm p-4">
            <div class="flex justify-between items-center">
                <span class="font-medium">${c.nome}</span>
                <div class="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                    <i class="fas ${c.icon || 'fa-paw'} text-orange-500 text-xl"></i>
                </div>
            </div>
        </div>
    `).join('');
}

function displayAdminList(categories) {
    const list = document.getElementById('adminList');
    if (!categories || categories.length === 0) {
        list.innerHTML = '<div class="text-center py-8">Nenhuma categoria cadastrada</div>';
        return;
    }
    list.innerHTML = categories.map(c => `
        <div class="bg-gray-50 rounded-lg p-4 flex justify-between items-center">
            <div>
                <h4 class="font-semibold">${c.nome}</h4>
                ${c.descricao ? `<p class="text-sm text-gray-600">${c.descricao}</p>` : ''}
                <span class="text-xs ${c.ativo ? 'text-green-600' : 'text-red-600'}">${c.ativo ? '● Ativo' : '● Inativo'}</span>
            </div>
            <div class="flex gap-2">
                <button onclick="editCategory(${c.id})" class="bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600"><i class="fas fa-edit"></i></button>
                <button onclick="deleteCategory(${c.id})" class="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600"><i class="fas fa-trash"></i></button>
            </div>
        </div>
    `).join('');
}

async function createCategory(event) {
    event.preventDefault();
    const data = {
        nome: document.getElementById('nome').value,
        descricao: document.getElementById('descricao').value,
        icon: document.getElementById('icon').value,
        ativo: document.getElementById('ativo').checked
    };
    try {
        const response = await fetch(API_CATEGORIAS, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        if (response.ok) {
            showStatus('✅ Categoria criada!', 'green');
            document.getElementById('categoryForm').reset();
            loadCategories();
        } else {
            showStatus('❌ Erro ao criar categoria', 'red');
        }
    } catch (error) {
        showStatus('❌ Erro: ' + error.message, 'red');
    }
}

async function editCategory(id) {
    const newName = prompt('Novo nome da categoria:');
    if (newName && newName.trim()) {
        try {
            const response = await fetch(`${API_CATEGORIAS}/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ nome: newName })
            });
            if (response.ok) {
                showStatus('✅ Categoria atualizada!', 'green');
                loadCategories();
            } else {
                showStatus('❌ Erro ao atualizar', 'red');
            }
        } catch (error) {
            showStatus('❌ Erro: ' + error.message, 'red');
        }
    }
}

async function deleteCategory(id) {
    if (confirm('Excluir esta categoria?')) {
        try {
            const response = await fetch(`${API_CATEGORIAS}/${id}`, { method: 'DELETE' });
            if (response.ok) {
                showStatus('✅ Categoria excluída!', 'green');
                loadCategories();
            } else {
                showStatus('❌ Erro ao excluir', 'red');
            }
        } catch (error) {
            showStatus('❌ Erro: ' + error.message, 'red');
        }
    }
}

function showStatus(msg, color) {
    const div = document.getElementById('status');
    div.className = `mb-4 p-3 rounded-lg ${color === 'green' ? 'bg-green-100 text-green-700 border border-green-300' : 'bg-red-100 text-red-700 border border-red-300'}`;
    div.innerHTML = `<i class="fas ${color === 'green' ? 'fa-check-circle' : 'fa-exclamation-circle'} mr-2"></i>${msg}`;
    div.classList.remove('hidden');
    setTimeout(() => div.classList.add('hidden'), 5000);
}

function openModal() {
    document.getElementById('adminModal').classList.remove('hidden');
    document.getElementById('adminModal').classList.add('flex');
}

function closeModal() {
    document.getElementById('adminModal').classList.add('hidden');
    document.getElementById('adminModal').classList.remove('flex');
}

// Event Listeners
document.addEventListener('DOMContentLoaded', async () => {
    await testarBackend();
    showTab('produtos');
    document.getElementById('categoryForm').addEventListener('submit', createCategory);
    document.getElementById('produtoForm').addEventListener('submit', saveProduto);
    document.getElementById('adminButton').onclick = openModal;
    document.getElementById('adminProdutoButton').onclick = () => openProdutoModal(null);
    
    document.getElementById('searchInput').addEventListener('input', async (e) => {
        if (currentView !== 'produtos') return;
        const term = e.target.value.toLowerCase();
        try {
            const response = await fetch(API_PRODUTOS);
            const produtos = await response.json();
            const filtered = produtos.filter(p => p.nome.toLowerCase().includes(term));
            displayProdutos(filtered);
        } catch (error) {}
    });
});

window.onclick = (e) => { 
    if (e.target === document.getElementById('adminModal')) closeModal();
    if (e.target === document.getElementById('produtoModal')) closeProdutoModal();
};