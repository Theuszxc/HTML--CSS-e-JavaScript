// ==================== THEUSPETSHOP — MÓDULO COMPARTILHADO ====================
// Inclua este arquivo em todas as páginas:
// <script src="petshop-utils.js"></script>

const PS = window.PS = (function () {

  // ---------- Configuração ----------
  const API_BASE = 'http://localhost:8080';
  const API      = `${API_BASE}/api`;

  const EP = {
    PRODUTOS        : `${API}/produtos`,
    PRODUTO         : (id) => `${API}/produtos/${id}`,
    CATEGORIAS      : `${API}/categorias`,
    CATEGORIA       : (id) => `${API}/categorias/${id}`,
    CARRINHO        : `${API}/carrinho`,
    CARRINHO_ADD    : `${API}/carrinho/adicionar`,
    CARRINHO_REMOVE : (id) => `${API}/carrinho/remover/${id}`,
    CARRINHO_UPDATE : (id) => `${API}/carrinho/atualizar/${id}`,
    CARRINHO_LIMPAR : `${API}/carrinho/limpar`,
    USUARIOS        : `${API}/usuarios`,
    USUARIO         : (id) => `${API}/usuarios/${id}`,
    PEDIDOS         : `${API}/pedidos`,
    PEDIDO_STATUS   : (id) => `${API}/pedidos/${id}/status`,
    LOGIN           : `${API}/auth/login`,
  };

  const SK = {
    TOKEN    : 'theus_auth_token',
    ADMIN    : 'theus_admin_session',
    USER     : 'theus_user_session',
    CART     : 'theus_cart_backup',
    CHECKOUT : 'theus_checkout_data',
    PRODS    : 'theus_products_backup',
    CATS     : 'theus_categories_backup',
    USERS    : 'theus_users_backup',
    ORDERS   : 'theus_orders_backup',
  };

  const IMG_DEFAULT = 'https://placehold.co/400x400/9A151A/white?text=TheusPetshop';

  // ---------- Auth ----------
  function getToken() { 
    return localStorage.getItem(SK.TOKEN); 
  }
  
  function getHeaders() {
    const h = { 'Content-Type': 'application/json' };
    const t = getToken();
    if (t) h['Authorization'] = `Bearer ${t}`;
    return h;
  }

  function isAdminLoggedIn() {
    return !!(localStorage.getItem(SK.ADMIN) && localStorage.getItem(SK.TOKEN));
  }

  function requireAdmin() {
    if (!isAdminLoggedIn()) {
      window.location.href = 'admin-login.html';
      return false;
    }
    return true;
  }

  function logout() {
    [SK.ADMIN, SK.TOKEN, SK.USER].forEach(function(k) {
      localStorage.removeItem(k);
    });
    window.location.href = 'admin-login.html';
  }

  // ---------- Toast ----------
  function toast(message, type = 'success') {
    let container = document.getElementById('toastContainer');
    if (!container) {
      container = document.createElement('div');
      container.id = 'toastContainer';
      container.style.cssText = 'position:fixed;bottom:1rem;right:1rem;z-index:9999;';
      document.body.appendChild(container);
    }
    
    const colors = { 
      success: '#10B981', 
      error: '#C21B12', 
      info: '#FC4B2A', 
      warning: '#F59E0B' 
    };
    
    const icons = { 
      success: 'check-circle', 
      error: 'alert-circle', 
      info: 'info', 
      warning: 'alert-triangle' 
    };
    
    const el = document.createElement('div');
    el.style.cssText = `background:${colors[type] || colors.info};color:#fff;padding:.75rem 1.25rem;border-radius:.75rem;margin-bottom:.5rem;display:flex;align-items:center;gap:.5rem;box-shadow:0 4px 12px rgba(0,0,0,.2);transition:opacity .3s;font-family:inherit;font-size:.875rem;`;
    el.innerHTML = `<i data-lucide="${icons[type] || 'info'}" style="width:16px;height:16px;flex-shrink:0;"></i>${message}`;
    container.appendChild(el);
    
    if (window.lucide) {
      lucide.createIcons({ nodes: [el] });
    }
    
    setTimeout(function() { 
      el.style.opacity = '0'; 
      setTimeout(function() { 
        if (el && el.remove) el.remove(); 
      }, 300); 
    }, 3200);
  }

  // ---------- Loading overlay ----------
  function loading(show) {
    let el = document.getElementById('globalLoading');
    if (!el) return;
    if (show) {
      el.classList.remove('hidden');
    } else {
      el.classList.add('hidden');
    }
  }

  // ---------- API genérica com fallback ----------
  async function apiFetch(url, options = {}) {
    const controller = new AbortController();
    const tid = setTimeout(function() { 
      controller.abort(); 
    }, 8000);
    
    try {
      const res = await fetch(url, { 
        ...options, 
        signal: controller.signal, 
        headers: getHeaders() 
      });
      clearTimeout(tid);
      return res;
    } catch (e) {
      clearTimeout(tid);
      throw e;
    }
  }

  async function apiStatus() {
    try {
      const r = await apiFetch(EP.CATEGORIAS, { method: 'HEAD' });
      return r.ok;
    } catch(e) { 
      return false; 
    }
  }

  // ---------- Carrinho ----------
  function getLocalCart() {
    try { 
      return JSON.parse(localStorage.getItem(SK.CART) || '[]');
    } catch(e) { 
      return []; 
    }
  }

  function saveLocalCart(cart) {
    localStorage.setItem(SK.CART, JSON.stringify(cart));
  }

  function localCartCount() {
    return getLocalCart().reduce(function(s, i) {
      return s + (i.quantidade || 1);
    }, 0);
  }

  async function cartCount() {
    try {
      const token = getToken();
      if (token) {
        const r = await apiFetch(EP.CARRINHO);
        if (r.ok) {
          const d = await r.json();
          return (d.itens || []).reduce(function(s, i) {
            return s + i.quantidade;
          }, 0);
        }
      }
    } catch(e) {}
    return localCartCount();
  }

  async function updateCartBadge() {
    const badge = document.getElementById('cartCountBadge');
    if (!badge) return;
    const n = await cartCount();
    badge.textContent = n;
    badge.style.display = n > 0 ? 'flex' : 'none';
  }

  async function addToCart(productId, quantidade, productData) {
    loading(true);
    try {
      const token = getToken();
      if (token) {
        const r = await apiFetch(EP.CARRINHO_ADD, {
          method: 'POST',
          body: JSON.stringify({ produtoId: productId, quantidade: quantidade })
        });
        if (r.ok) { 
          toast('Produto adicionado ao carrinho!'); 
          await updateCartBadge(); 
          loading(false);
          return; 
        }
      }
    } catch(e) {}

    // Fallback localStorage
    const cart = getLocalCart();
    const idx = cart.findIndex(function(i) { 
      return i.id === productId; 
    });
    
    if (idx >= 0) {
      cart[idx].quantidade = (cart[idx].quantidade || 1) + quantidade;
    } else if (productData) {
      cart.push({
        id: productData.idProduto || productId,
        nome: productData.nome,
        preco: productData.precoDesconto || productData.preco,
        quantidade: quantidade,
        imagem: productData.imagem || IMG_DEFAULT,
      });
    } else {
      toast('Erro ao adicionar produto', 'error');
      loading(false);
      return;
    }
    saveLocalCart(cart);
    toast('Produto adicionado ao carrinho!');
    await updateCartBadge();
    loading(false);
  }

  // ---------- Dados mock (fallback offline) ----------
  const MOCK = {
    categorias: [
      { idCategoria:1, nome:'Cachorros', icone:'dog' },
      { idCategoria:2, nome:'Gatos',     icone:'cat' },
      { idCategoria:3, nome:'Aves',      icone:'bird' },
      { idCategoria:4, nome:'Peixes',    icone:'fish' },
      { idCategoria:5, nome:'Roedores',  icone:'rabbit' },
      { idCategoria:6, nome:'Saúde',     icone:'heart' },
    ],
    produtos: [
      { idProduto:1, nome:'Ração Premium Cães 10kg',  preco:89.90, precoDesconto:69.90, imagem:'https://placehold.co/400x400/9A151A/white?text=Racao+Cachorro', idCategoria:1, qtdEstoque:50,  descricao:'Alimentação completa para cães adultos. Enriquecida com vitaminas A, D e E.' },
      { idProduto:2, nome:'Brinquedo Mordedor',        preco:35.90, precoDesconto:25.90, imagem:'https://placehold.co/400x400/9A151A/white?text=Brinquedo', idCategoria:1, qtdEstoque:100, descricao:'Brinquedo interativo de borracha resistente, ideal para filhotes e adultos.' },
      { idProduto:3, nome:'Arranhador Gato Premium',   preco:89.90, precoDesconto:69.90, imagem:'https://placehold.co/400x400/9A151A/white?text=Arranhador', idCategoria:2, qtdEstoque:30,  descricao:'Arranhador vertical com bola de sisal, perfeito para gatos domésticos.' },
      { idProduto:4, nome:'Gaiola para Pássaros',      preco:199.90,precoDesconto:169.90,imagem:'https://placehold.co/400x400/9A151A/white?text=Gaiola', idCategoria:3, qtdEstoque:15,  descricao:'Gaiola espaçosa com comedouro, bebedouro e poleiro incluso.' },
      { idProduto:5, nome:'Aquário 20L Completo',      preco:149.90,precoDesconto:129.90,imagem:'https://placehold.co/400x400/9A151A/white?text=Aquario', idCategoria:4, qtdEstoque:20,  descricao:'Aquário completo com filtro, LED e termômetro inclusos.' },
      { idProduto:6, nome:'Antipulgas Vet',            preco:45.90, precoDesconto:39.90, imagem:'https://placehold.co/400x400/9A151A/white?text=Antipulgas', idCategoria:6, qtdEstoque:80,  descricao:'Antipulgas de longa duração (4 meses). Para cães e gatos acima de 2kg.' },
    ],
  };

  async function fetchProdutos() {
    try {
      const r = await apiFetch(EP.PRODUTOS);
      if (r.ok) {
        const d = await r.json();
        localStorage.setItem(SK.PRODS, JSON.stringify(d));
        return d;
      }
    } catch(e) {}
    const local = localStorage.getItem(SK.PRODS);
    return local ? JSON.parse(local) : MOCK.produtos;
  }

  async function fetchProduto(id) {
    try {
      const r = await apiFetch(EP.PRODUTO(id));
      if (r.ok) return await r.json();
    } catch(e) {}
    // fallback: busca no cache local ou mock
    const todos = JSON.parse(localStorage.getItem(SK.PRODS) || '[]');
    return todos.find(function(p) { 
      return p.idProduto === id; 
    }) || MOCK.produtos.find(function(p) { 
      return p.idProduto === id; 
    }) || null;
  }

  async function fetchCategorias() {
    try {
      const r = await apiFetch(EP.CATEGORIAS);
      if (r.ok) {
        const d = await r.json();
        localStorage.setItem(SK.CATS, JSON.stringify(d));
        return d;
      }
    } catch(e) {}
    const local = localStorage.getItem(SK.CATS);
    return local ? JSON.parse(local) : MOCK.categorias;
  }

  async function fetchUsuarios() {
    try {
      const r = await apiFetch(EP.USUARIOS);
      if (r.ok) {
        const d = await r.json();
        localStorage.setItem(SK.USERS, JSON.stringify(d));
        return d;
      }
    } catch(e) {}
    const local = localStorage.getItem(SK.USERS);
    return local ? JSON.parse(local) : [];
  }

  async function fetchPedidos() {
    try {
      const r = await apiFetch(EP.PEDIDOS);
      if (r.ok) {
        const d = await r.json();
        localStorage.setItem(SK.ORDERS, JSON.stringify(d));
        return d;
      }
    } catch(e) {}
    const local = localStorage.getItem(SK.ORDERS);
    return local ? JSON.parse(local) : [];
  }

  // ---------- Inicializa defaults de armazenamento ----------
  function initStorage() {
    if (!localStorage.getItem(SK.PRODS)) {
      localStorage.setItem(SK.PRODS, JSON.stringify(MOCK.produtos));
    }
    if (!localStorage.getItem(SK.CATS)) {
      localStorage.setItem(SK.CATS, JSON.stringify(MOCK.categorias));
    }
    if (!localStorage.getItem(SK.USERS)) {
      localStorage.setItem(SK.USERS, JSON.stringify([]));
    }
    if (!localStorage.getItem(SK.ORDERS)) {
      localStorage.setItem(SK.ORDERS, JSON.stringify([]));
    }
    if (!localStorage.getItem(SK.CART)) {
      localStorage.setItem(SK.CART, JSON.stringify([]));
    }
  }

  // ---------- Helpers de formatação ----------
  function brl(n) { 
    return 'R$ ' + Number(n).toFixed(2).replace('.', ','); 
  }
  
  function pct(orig, desc) { 
    return Math.round((1 - desc / orig) * 100); 
  }

  // ---------- CEP ----------
  async function buscarCep(cep) {
    const c = cep.replace(/\D/g, '');
    if (c.length !== 8) return null;
    try {
      const r = await fetch('https://viacep.com.br/ws/' + c + '/json/');
      const d = await r.json();
      return d.erro ? null : d;
    } catch(e) { 
      return null; 
    }
  }

  // Inicializa armazenamento automaticamente
  initStorage();

  // ---------- API pública ----------
  return {
    // Configurações
    EP: EP,
    SK: SK,
    IMG_DEFAULT: IMG_DEFAULT,
    MOCK: MOCK,
    
    // Auth
    getToken: getToken,
    getHeaders: getHeaders,
    isAdminLoggedIn: isAdminLoggedIn,
    requireAdmin: requireAdmin,
    logout: logout,
    
    // UI
    toast: toast,
    loading: loading,
    
    // API
    apiStatus: apiStatus,
    apiFetch: apiFetch,
    
    // Carrinho
    getLocalCart: getLocalCart,
    saveLocalCart: saveLocalCart,
    localCartCount: localCartCount,
    cartCount: cartCount,
    updateCartBadge: updateCartBadge,
    addToCart: addToCart,
    
    // Dados
    fetchProdutos: fetchProdutos,
    fetchProduto: fetchProduto,
    fetchCategorias: fetchCategorias,
    fetchUsuarios: fetchUsuarios,
    fetchPedidos: fetchPedidos,
    
    // Helpers
    initStorage: initStorage,
    brl: brl,
    pct: pct,
    buscarCep: buscarCep
  };

})();

// Garantir que o localStorage seja inicializado quando o script carregar
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', function() {
    PS.initStorage();
  });
} else {
  PS.initStorage();
}