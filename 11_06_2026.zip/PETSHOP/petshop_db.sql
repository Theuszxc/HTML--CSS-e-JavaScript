-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 26/05/2026 às 18:13
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `petshop_db`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `categoria`
--

CREATE TABLE `categoria` (
  `id_categoria` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `descricao` text DEFAULT NULL,
  `ativo` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `categoria`
--

INSERT INTO `categoria` (`id_categoria`, `nome`, `descricao`, `ativo`) VALUES
(1, 'Cachorro', 'Ração para cachorros', 1),
(2, 'Gato', 'Ração e brinquedos para gatos', 1),
(3, 'Pássaro', 'Ração e remédios para pássaros', 1),
(4, 'Peixe', 'Ração para peixes', 1),
(7, 'Outros Pets', 'Outros Pets', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `itens_pedido`
--

CREATE TABLE `itens_pedido` (
  `id_item_pedido` int(11) NOT NULL,
  `id_pedido_fk` int(11) NOT NULL,
  `id_produto_fk` int(11) NOT NULL,
  `nome_produto` varchar(255) NOT NULL,
  `quantidade` int(11) NOT NULL,
  `preco_unitario` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `itens_pedido`
--

INSERT INTO `itens_pedido` (`id_item_pedido`, `id_pedido_fk`, `id_produto_fk`, `nome_produto`, `quantidade`, `preco_unitario`) VALUES
(13, 2, 1, 'Tapete Higiênico Petz para Cães', 1, 97.99),
(14, 3, 1, 'Tapete Higiênico Petz para Cães', 3, 97.99),
(15, 4, 2, 'Ração Golden Special para Cães Adultos', 1, 159.90),
(16, 4, 3, 'Ração Úmida GranPlus Gourmet Sachê para Cães ', 1, 3.39),
(19, 5, 1, 'Tapete Higiênico Petz para Cães', 5, 97.99),
(20, 5, 2, 'Ração Golden Special para Cães Adultos', 2, 159.90),
(21, 6, 1, 'Tapete Higiênico Petz para Cães', 1, 97.99),
(22, 6, 2, 'Ração Golden Special para Cães Adultos', 1, 159.90),
(28, 8, 1, 'Tapete Higiênico Petz para Cães', 1, 90.00),
(29, 8, 2, 'Ração Golden Special para Cães Adultos', 1, 152.00),
(30, 9, 1, 'Tapete Higiênico Petz para Cães', 1, 90.00),
(31, 9, 2, 'Ração Golden Special para Cães Adultos', 1, 152.00),
(32, 9, 3, 'Ração Úmida GranPlus Gourmet Sachê para Cães ', 1, 3.00),
(33, 10, 1, 'Tapete Higiênico Petz para Cães', 1, 90.00),
(34, 11, 1, 'Tapete Higiênico Petz para Cães', 1, 90.00),
(35, 11, 2, 'Ração Golden Special para Cães Adultos', 3, 152.00),
(36, 12, 2, 'Ração Golden Special para Cães Adultos', 1, 152.00),
(37, 12, 3, 'Ração Úmida GranPlus Gourmet Sachê para Cães ', 1, 3.00),
(38, 13, 2, 'Ração Golden Special para Cães Adultos', 1, 152.00),
(39, 13, 3, 'Ração Úmida GranPlus Gourmet Sachê para Cães ', 1, 3.00),
(40, 13, 4, 'Prediderm Ourofino 5mg 10 Comprimidos', 1, 21.90),
(41, 14, 3, 'Ração Úmida GranPlus Gourmet Sachê para Cães ', 1, 3.00),
(42, 14, 4, 'Prediderm Ourofino 5mg 10 Comprimidos', 1, 21.90),
(43, 15, 4, 'Prediderm Ourofino 5mg 10 Comprimidos', 10, 21.90),
(44, 16, 5, 'Areia Higiênica Viva Verde Grãos Finos para Gatos', 1, 62.91),
(45, 17, 1, 'Tapete Higiênico Petz para Cães', 1, 90.00),
(46, 18, 2, 'Ração Golden Special para Cães Adultos', 1, 152.00),
(47, 19, 3, 'Ração Úmida GranPlus Gourmet Sachê para Cães ', 1, 3.00),
(48, 20, 3, 'Ração Úmida GranPlus Gourmet Sachê para Cães ', 1, 3.00),
(49, 21, 1, 'Tapete Higiênico Petz para Cães', 1, 90.00),
(50, 22, 1, 'Tapete Higiênico Petz para Cães', 1, 90.00),
(51, 23, 1, 'Tapete Higiênico Petz para Cães', 2, 90.00),
(52, 24, 2, 'Ração Golden Special para Cães Adultos', 1, 152.00),
(53, 24, 4, 'Prediderm Ourofino 5mg 10 Comprimidos', 4, 21.90),
(54, 24, 3, 'Ração Úmida GranPlus Gourmet Sachê para Cães ', 1, 3.00),
(55, 25, 1, 'Tapete Higiênico Petz para Cães', 3, 90.00),
(56, 25, 2, 'Ração Golden Special para Cães Adultos', 1, 152.00),
(57, 26, 1, 'Tapete Higiênico Petz para Cães', 1, 90.00),
(58, 27, 1, 'Tapete Higiênico Petz para Cães', 10, 90.00),
(59, 28, 1, 'Tapete Higiênico Petz para Cães', 1, 90.00),
(60, 29, 1, 'Tapete Higiênico Petz para Cães', 1, 90.00),
(61, 29, 5, 'Areia Higiênica Viva Verde Grãos Finos para Gatos', 6, 62.91),
(62, 30, 4, 'Prediderm Ourofino 5mg 10 Comprimidos', 1, 21.90),
(63, 30, 1, 'Tapete Higiênico Petz para Cães', 1, 90.00),
(64, 30, 5, 'Areia Higiênica Viva Verde Grãos Finos para Gatos', 3, 62.91);

-- --------------------------------------------------------

--
-- Estrutura para tabela `pedidos`
--

CREATE TABLE `pedidos` (
  `id_pedido` int(11) NOT NULL,
  `id_usuario_fk` int(11) NOT NULL,
  `data_pedido` datetime DEFAULT current_timestamp(),
  `status` varchar(50) DEFAULT NULL,
  `valor_total` decimal(10,2) DEFAULT NULL,
  `endereco_entrega` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `pedidos`
--

INSERT INTO `pedidos` (`id_pedido`, `id_usuario_fk`, `data_pedido`, `status`, `valor_total`, `endereco_entrega`) VALUES
(2, 1, '2026-05-12 13:55:04', 'FINALIZADO', 97.99, NULL),
(3, 1, '2026-05-14 08:33:03', 'FINALIZADO', 293.97, NULL),
(4, 1, '2026-05-14 08:37:40', 'FINALIZADO', 163.29, NULL),
(5, 1, '2026-05-14 08:38:04', 'FINALIZADO', 809.75, NULL),
(6, 1, '2026-05-14 09:03:26', 'FINALIZADO', 257.89, NULL),
(7, 1, '2026-05-14 11:32:27', 'ABERTO', 0.00, NULL),
(8, 4, '2026-05-14 14:26:33', 'FINALIZADO', 242.00, NULL),
(9, 4, '2026-05-14 15:07:42', 'FINALIZADO', 245.00, NULL),
(10, 4, '2026-05-14 15:08:04', 'FINALIZADO', 90.00, NULL),
(11, 4, '2026-05-14 15:49:06', 'FINALIZADO', 546.00, NULL),
(12, 6, '2026-05-19 09:13:00', 'CANCELADO', 155.00, NULL),
(13, 6, '2026-05-19 10:47:48', 'CANCELADO', 176.90, NULL),
(14, 6, '2026-05-19 10:53:31', 'CANCELADO', 24.90, NULL),
(15, 6, '2026-05-19 11:01:53', 'FINALIZADO', 219.00, NULL),
(16, 7, '2026-05-19 11:12:52', 'FINALIZADO', 62.91, NULL),
(17, 6, '2026-05-21 09:10:20', 'FINALIZADO', 90.00, NULL),
(18, 6, '2026-05-21 09:11:02', 'CANCELADO', 152.00, NULL),
(19, 6, '2026-05-21 09:15:07', 'CANCELADO', 3.00, NULL),
(20, 6, '2026-05-21 10:06:35', 'CANCELADO', 3.00, NULL),
(21, 6, '2026-05-21 14:54:14', 'CANCELADO', 90.00, NULL),
(22, 9, '2026-05-21 14:58:56', 'FINALIZADO', 90.00, NULL),
(23, 9, '2026-05-21 15:06:26', 'FINALIZADO', 180.00, NULL),
(24, 9, '2026-05-21 15:07:00', 'FINALIZADO', 242.60, NULL),
(25, 9, '2026-05-21 15:24:03', 'FINALIZADO', 422.00, NULL),
(26, 9, '2026-05-21 15:28:22', 'FINALIZADO', 90.00, NULL),
(27, 9, '2026-05-21 15:29:03', 'FINALIZADO', 900.00, NULL),
(28, 9, '2026-05-21 15:31:26', 'FINALIZADO', 90.00, NULL),
(29, 9, '2026-05-21 15:37:06', 'FINALIZADO', 467.46, NULL),
(30, 7, '2026-05-21 15:39:34', 'CANCELADO', 300.63, NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `produto`
--

CREATE TABLE `produto` (
  `id_produto` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `descricao` text DEFAULT NULL,
  `preco` decimal(10,2) NOT NULL,
  `preco_desconto` decimal(10,2) DEFAULT NULL,
  `imagem` longtext DEFAULT NULL,
  `sku` varchar(50) DEFAULT NULL,
  `qtd_estoque` int(11) DEFAULT 0,
  `ativo` tinyint(1) DEFAULT 1,
  `id_categoria` int(11) DEFAULT NULL,
  `data_criacao` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `produto`
--

INSERT INTO `produto` (`id_produto`, `nome`, `descricao`, `preco`, `preco_desconto`, `imagem`, `sku`, `qtd_estoque`, `ativo`, `id_categoria`, `data_criacao`) VALUES
(1, 'Tapete Higiênico Petz para Cães', 'Tapete Higiênico Petz para Cães Superabsorvente 30 Unidades', 97.99, 90.00, '/9j/4AAQSkZJRgABAQAAAQABAAD...', NULL, 10, 1, 1, '2026-05-12 11:54:04'),
(2, 'Ração Golden Special para Cães Adultos', 'Ração Golden Special para Cães Adultos Sabor Frango e Carne', 159.90, 152.00, '/9j/4AAQSkZJRgABAgAAAQABAAD...', NULL, 23, 1, 1, '2026-05-12 11:55:05'),
(3, 'Ração Úmida GranPlus Gourmet Sachê para Cães ', 'Ração Úmida GranPlus Gourmet Sachê para Cães Adultos Sabor Carne - 100g', 3.39, 3.00, '/9j/4AAQSkZJRgABAgAAAQABAAD...', NULL, 200, 1, 1, '2026-05-12 11:56:26'),
(4, 'Prediderm Ourofino 5mg 10 Comprimidos', 'Prediderm Ourofino 5mg 10 Comprimidos', 21.90, 21.90, '/9j/4QAYRXhpZgAASUkqAAgAAAAAAAAAAAAAAP...', NULL, 20, 1, 1, '2026-05-12 13:03:39'),
(5, 'Areia Higiênica Viva Verde Grãos Finos para Gatos', 'Areia Higiênica Viva Verde Grãos Finos para Gatos', 69.90, 62.91, '/9j/4AAQSkZJRgABAgAAAQABAAD...', NULL, 122, 1, 2, '2026-05-19 11:11:49');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `perfil` varchar(20) DEFAULT 'USER',
  `endereco` varchar(255) DEFAULT NULL,
  `bairro` varchar(100) DEFAULT NULL,
  `complemento` varchar(100) DEFAULT NULL,
  `cep` varchar(20) DEFAULT NULL,
  `cidade` varchar(100) DEFAULT NULL,
  `estado` varchar(50) DEFAULT NULL,
  `foto` longtext DEFAULT NULL,
  `data_cadastro` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `email`, `senha`, `perfil`, `endereco`, `bairro`, `complemento`, `cep`, `cidade`, `estado`, `foto`, `data_cadastro`) VALUES
(1, 'Jurandir', 'juras@senai.br', '$2a$10$FmTMU.NQiAYselkj2GihJOMwOuynw0bpaLwcxFYxbYpgIFY/yOopC', 'USER', 'Rua do Senai', 'Teste', '123', '1212123', '121', '222', NULL, '2026-05-12 13:52:27'),
(2, 'Jurandir', 'jurandir@senai.br', '$2a$10$ZyZD8baZo.levcMqM.LxZODIl.Ze24z4beHj0cXvX8Ke5nSPaRaRS', 'USER', 'Rua do Senai', '23', '23', '23', '23', '23', 'data:image/png;base64,...', '2026-05-14 10:26:16'),
(4, 'Jurandir', 'jurandir.fmb@gmail.com', '$2a$10$nN6xzU7nZCSRz1U.jallRug/ea.YI.TVNeuLW5r9GiXhDZkGQ/dnG', 'ADMIN', 'Rua Amanador', 'Santana', '12', '1800000', 'Sorocaba', 'SP', 'data:image/png;base64,...', '2026-05-14 10:55:55'),
(6, 'Teste', 'teste@teste.com', '$2a$10$aFK71L4V.ntjjxT2GOzSx.aQzgSdbA3jDZicUKX.BPYqj3/sob5uW', 'USER', '12', '12', '12', '12', '12', '12', 'data:image/png;base64,...', '2026-05-19 09:12:07'),
(7, 'Anna Lara', 'ana@gmail.com', '$2a$10$os0UDndHBB5fyiBkuX2CkO58akUZLNd0u4nzKuanknXw.xOIxrDFW', 'USER', '1212', '121', '1212', '1221212', '121', '121', 'data:image/png;base64,...', '2026-05-19 11:08:26'),
(9, 'Anna Lara', 'anna@gmail.com', '$2a$10$mK3LHnQ5oq9uLR0CWMu7h.z4SSY10Dnzyx0lFLqPq0.pvdXa4eBF.', 'USER', 'Rua das Alamedas, 123', 'São Bento', 'Apto 33', '121111212', 'Sorocaba', 'SP', 'data:image/png;base64,...', '2026-05-21 14:02:21');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `categoria`
--
ALTER TABLE `categoria`
  ADD PRIMARY KEY (`id_categoria`);

--
-- Índices de tabela `itens_pedido`
--
ALTER TABLE `itens_pedido`
  ADD PRIMARY KEY (`id_item_pedido`),
  ADD KEY `fk_itens_pedido` (`id_pedido_fk`),
  ADD KEY `fk_itens_produto` (`id_produto_fk`);

--
-- Índices de tabela `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id_pedido`),
  ADD KEY `fk_pedido_usuario` (`id_usuario_fk`);

--
-- Índices de tabela `produto`
--
ALTER TABLE `produto`
  ADD PRIMARY KEY (`id_produto`),
  ADD KEY `fk_produto_categoria` (`id_categoria`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `categoria`
--
ALTER TABLE `categoria`
  MODIFY `id_categoria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `itens_pedido`
--
ALTER TABLE `itens_pedido`
  MODIFY `id_item_pedido` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT de tabela `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id_pedido` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT de tabela `produto`
--
ALTER TABLE `produto`
  MODIFY `id_produto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `itens_pedido`
--
ALTER TABLE `itens_pedido`
  ADD CONSTRAINT `fk_itens_pedido` FOREIGN KEY (`id_pedido_fk`) REFERENCES `pedidos` (`id_pedido`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_itens_produto` FOREIGN KEY (`id_produto_fk`) REFERENCES `produto` (`id_produto`);

--
-- Restrições para tabelas `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `fk_pedido_usuario` FOREIGN KEY (`id_usuario_fk`) REFERENCES `usuarios` (`id`);

--
-- Restrições para tabelas `produto`
--
ALTER TABLE `produto`
  ADD CONSTRAINT `fk_produto_categoria` FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id_categoria`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
