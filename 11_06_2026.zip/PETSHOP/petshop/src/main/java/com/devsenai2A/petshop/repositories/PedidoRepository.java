
package com.devsenai2A.petshop.repositories;

import com.devsenai2A.petshop.entities.Pedido;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface PedidoRepository extends JpaRepository<Pedido, Integer> {

    // O nome do método DEVE seguir o nome da variável na classe Pedido
    // Se na classe está 'idUsuarioFk', aqui deve ser 'findByIdUsuarioFk'
    Optional<Pedido> findByIdUsuarioFkAndStatus(Long idUsuarioFk, String status);
    
    //Listar pedidos por Usuario
    List<Pedido> findByIdUsuarioFk(Long idUsuario);

}