package com.devsenai2A.petshop.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.devsenai2A.petshop.entities.ItensPedido;
import com.devsenai2A.petshop.entities.Produto;
import com.devsenai2A.petshop.repositories.ItensPedidoRepository;
import com.devsenai2A.petshop.repositories.ProdutoRepository;

@Service
public class ItensPedidoService {

    @Autowired private ItensPedidoRepository itensPedidoRepository;
    @Autowired private ProdutoRepository produtoRepository;

    public void adicionarOuAtualizarItem(Integer idPedido, Integer idProduto, Integer quantidade) {
        Produto produto = produtoRepository.findById(idProduto)
                .orElseThrow(() -> new RuntimeException("Produto não encontrado"));

        Optional<ItensPedido> itemExistente = itensPedidoRepository
                .findByIdPedidoFkAndIdProdutoFk(idPedido, idProduto);

        if (itemExistente.isPresent()) {
            ItensPedido item = itemExistente.get();
            item.setQuantidade(item.getQuantidade() + quantidade);
            itensPedidoRepository.save(item);
        } else {
            ItensPedido novoItem = new ItensPedido();
            novoItem.setIdPedidoFk(idPedido);
            novoItem.setIdProdutoFk(idProduto);
            novoItem.setNomeProduto(produto.getNome());
            novoItem.setQuantidade(quantidade);
            novoItem.setPrecoUnitario(produto.getPreco_desconto());
            itensPedidoRepository.save(novoItem);
        }
    }

    public List<ItensPedido> listarPorPedido(Integer idPedido) {
        return itensPedidoRepository.findByIdPedidoFk(idPedido);
    }

    public void remover(Integer idItemPedido) {
        itensPedidoRepository.deleteById(idItemPedido);
    }
    
    public void limparItensDoPedido(Integer idPedido) {
        List<ItensPedido> itens = itensPedidoRepository.findByIdPedidoFk(idPedido);
        itensPedidoRepository.deleteAll(itens);
    }

}