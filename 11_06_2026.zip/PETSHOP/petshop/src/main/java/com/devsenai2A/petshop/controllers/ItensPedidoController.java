package com.devsenai2A.petshop.controllers;

import com.devsenai2A.petshop.entities.ItensPedido;
import com.devsenai2A.petshop.services.PedidoService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/itens-pedido")
public class ItensPedidoController {

    @Autowired
    private PedidoService pedidoService; // O PedidoService orquestra a regra de negócio

    // Adicionar um produto (ou aumentar quantidade)
    @PostMapping("/adicionar")
    public ResponseEntity<String> adicionarItem(
            @RequestParam Long usuarioId, 
            @RequestParam Integer produtoId, 
            @RequestParam Integer quantidade) {
        
        pedidoService.adicionarAoCarrinho(usuarioId, produtoId, quantidade);
        return ResponseEntity.ok("Item adicionado ao carrinho!");
    }
    
    //LISTAR ITENS POR PEDIDO (Faltava este para o front-end renderizar a lista)
    @GetMapping("/pedido/{idPedido}")
    public ResponseEntity<List<ItensPedido>> listarPorPedido(@PathVariable Integer idPedido) {
        List<ItensPedido> itens = pedidoService.buscarItensPorPedido(idPedido);
        return ResponseEntity.ok(itens);
    }

    // Remover um item específico da lista
    @DeleteMapping("/{idItemPedido}/pedido/{idPedido}")
    public ResponseEntity<String> removerItem(
            @PathVariable Integer idItemPedido, 
            @PathVariable Integer idPedido) {
        
        pedidoService.removerItemDoCarrinho(idItemPedido, idPedido);
        return ResponseEntity.ok("Item removido!");
    }
}